"""
Statistiques publiques des mineurs.

Le minage est ouvert : aucun mineur n'a besoin d'être déclaré. Ce module se contente
de compter les blocs et les récompenses par adresse, pour /info et /miners.
"""
import datetime

from db import SessionLocal, MinerModel

# Conservé pour compatibilité avec l'import historique de network/api.py
miners_registry = {}


def _now() -> datetime.datetime:
    # Heure UTC « naïve » : c'est ce que les bases SQLite/PostgreSQL stockent pour un DateTime simple.
    return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)


def _get_or_create(db, miner_pub: str) -> MinerModel:
    row = db.query(MinerModel).filter(MinerModel.miner_pub == miner_pub).first()
    if row is None:
        row = MinerModel(
            miner_id=f"miner-{miner_pub[:12]}",
            miner_pub=miner_pub,
            last_seen=_now(),
            blocks_mined=0,
            total_reward=0.0,
        )
        db.add(row)
    return row


def touch_miner(miner_pub: str, ip: str = None) -> None:
    """Marque une adresse comme active."""
    if not miner_pub:
        return
    db = SessionLocal()
    try:
        row = _get_or_create(db, miner_pub)
        row.last_seen = _now()
        if ip:
            row.ip = ip
        db.commit()
    except Exception:
        db.rollback()
    finally:
        db.close()


def mark_block_mined(miner_pub: str, amount: int = 0) -> None:
    """Enregistre un bloc accepté pour cette adresse."""
    if not miner_pub:
        return
    db = SessionLocal()
    try:
        row = _get_or_create(db, miner_pub)
        row.last_seen = _now()
        row.blocks_mined = int(row.blocks_mined or 0) + 1
        row.total_reward = float(row.total_reward or 0.0) + float(amount or 0)
        db.commit()
    except Exception:
        db.rollback()
    finally:
        db.close()


def compute_miner_stats() -> dict:
    db = SessionLocal()
    try:
        now = _now()
        total = db.query(MinerModel).count()
        active_15m = (
            db.query(MinerModel)
            .filter(MinerModel.last_seen >= now - datetime.timedelta(minutes=15))
            .count()
        )
        active_24h = (
            db.query(MinerModel)
            .filter(MinerModel.last_seen >= now - datetime.timedelta(hours=24))
            .count()
        )
        return {
            "total_registered": total,
            "active_15m": active_15m,
            "active_24h": active_24h,
        }
    except Exception:
        return {"total_registered": 0, "active_15m": 0, "active_24h": 0}
    finally:
        db.close()
