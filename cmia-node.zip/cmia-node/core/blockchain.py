import json
import hashlib
import time
import os
from ecdsa import VerifyingKey, SigningKey, SECP256k1, BadSignatureError
from ecdsa.util import sigdecode_string
import math
from db import (
    BlockModel,
    UTXOModel,
    TransactionModel,
    TransactionInputModel,
    TransactionOutputModel,
)

# Variables globales ou constantes par défaut (gérées par l'environnement plus tard)
MAX_TARGET = 2**240
NETWORK_ID = os.getenv("NETWORK_ID", "cmia-mainnet-v1")
GENESIS_TIMESTAMP = 1760000000
TX_VERSION = int(os.getenv("TX_VERSION", "1"))
INITIAL_REWARD = 25
HALVING_EVERY_BLOCKS = 5000
DIFFICULTY_ADJUST_EVERY_BLOCKS = 5
TARGET_BLOCK_TIME_SECONDS = 30
MIN_DIFFICULTY = 3
MAX_DIFFICULTY = 240


def difficulty_to_target(difficulty: int) -> int:
    """
    CMIA utilise une difficulté exprimée en bits de travail.

    difficulty=3  -> ~8 hashes en moyenne
    difficulty=20 -> ~1 048 576 hashes
    difficulty=30 -> ~1 073 741 824 hashes
    """
    difficulty = int(difficulty)
    difficulty = max(MIN_DIFFICULTY, min(MAX_DIFFICULTY, difficulty))

    return 2 ** (256 - difficulty)


def block_meets_target(block_hash: str, difficulty: int) -> bool:
    try:
        value = int(block_hash, 16)
    except (TypeError, ValueError):
        return False

    return value < difficulty_to_target(int(difficulty))


def block_hash_of(block_data: dict) -> str:
    candidate = block_data.copy()
    candidate.pop("hash", None)

    raw = json.dumps(
        candidate,
        sort_keys=True,
        separators=(",", ":"),
    ).encode()

    return hashlib.sha256(raw).hexdigest()


def mine_pow(block_data: dict, difficulty: int) -> dict:
    """
    Minage local.
    Cette fonction reste utile pour les tests et éventuellement
    pour un mineur embarqué, mais le noeud ne l'utilise plus
    pour miner à la place du client.
    """
    target = difficulty_to_target(difficulty)

    data = block_data.copy()
    nonce = 0

    while True:
        data["nonce"] = nonce

        block_hash = block_hash_of(data)

        if int(block_hash, 16) < target:
            data["hash"] = block_hash
            return data

        nonce += 1
        
def now_ts() -> int:
    return int(time.time())

def tx_hash_of(sender_pub: str, recipient_pub: str, amount: int, signature: str, created_at: int) -> str:
    raw = f"{sender_pub}|{recipient_pub}|{amount}|{signature}|{created_at}"
    return hashlib.sha256(raw.encode()).hexdigest()

def strict_tx_hash_of(sender_pub: str, inputs: list[dict], outputs: list[dict], signature: str, created_at: int) -> str:
    raw = json.dumps(
        {
            "sender_pub": sender_pub,
            "inputs": inputs,
            "outputs": outputs,
            "signature": signature,
            "created_at": created_at,
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(raw.encode()).hexdigest()


def coinbase_tx_hash(
    miner_pub: str,
    amount: int,
    created_at: int,
    height: int,
) -> str:
    raw = (
        f"{NETWORK_ID}|"
        f"{TX_VERSION}|"
        f"NETWORK|"
        f"{miner_pub}|"
        f"{amount}|"
        f"{created_at}|"
        f"{height}"
    )

    return hashlib.sha256(raw.encode()).hexdigest()
    
def recalc_reward_for_height(height: int) -> int:
    halvings = height // HALVING_EVERY_BLOCKS
    reward = INITIAL_REWARD
    for _ in range(halvings):
        reward = max(1, reward // 2)
    return reward

def spending_intent_message(network_id: str, tx_version: int, sender_pub: str, inputs: list[dict], outputs: list[dict], fee: int) -> str:
    payload = {
        "network_id": network_id,
        "tx_version": tx_version,
        "sender_pub": sender_pub,
        "inputs": inputs,
        "outputs": outputs,
        "fee": fee,
    }
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))

def verify_strict_signature(sender_pub: str, inputs: list[dict], outputs: list[dict], signature: str, fee: int) -> bool:
    if sender_pub == "NETWORK":
        return True
    if not signature:
        return False

    try:
        vk = VerifyingKey.from_string(bytes.fromhex(sender_pub), curve=SECP256k1)
        unsigned_inputs = [
            {
                "prev_tx_hash": i["prev_tx_hash"],
                "output_index": int(i["output_index"]),
            }
            for i in inputs
        ]

        message = spending_intent_message(
            NETWORK_ID,
            TX_VERSION,
            sender_pub,
            unsigned_inputs,
            outputs,
            fee,
        )

        digest = hashlib.sha256(message.encode()).digest()
        return vk.verify_digest(
            bytes.fromhex(signature),
            digest,
            sigdecode=sigdecode_string,
        )
    except (BadSignatureError, ValueError, AssertionError, KeyError):
        return False



def validate_coinbase(block: dict) -> bool:
    txs = block.get("transactions", [])

    if not isinstance(txs, list) or not txs:
        return False

    coinbase = txs[0]

    if not isinstance(coinbase, dict):
        return False

    # La coinbase doit être la première transaction
    if coinbase.get("sender_pub") != "NETWORK":
        return False

    # Une seule coinbase autorisée
    coinbase_count = sum(
        1
        for tx in txs
        if isinstance(tx, dict)
        and tx.get("sender_pub") == "NETWORK"
    )

    if coinbase_count != 1:
        return False

    required = {
        "tx_hash",
        "sender_pub",
        "recipient_pub",
        "amount",
        "created_at",
        "type",
        "tx_version",
        "network_id",
    }

    if not required.issubset(coinbase.keys()):
        return False

    if coinbase.get("type") != "coinbase":
        return False

    if coinbase.get("network_id") != NETWORK_ID:
        return False

    try:
        tx_version = int(coinbase.get("tx_version"))
    except (TypeError, ValueError):
        return False

    if tx_version != TX_VERSION:
        return False

    miner_pub = coinbase.get("recipient_pub")

    if not isinstance(miner_pub, str) or len(miner_pub) < 16:
        return False

    try:
        amount = int(coinbase.get("amount"))
        created_at = int(coinbase.get("created_at"))
        height = int(block.get("height"))
    except (TypeError, ValueError):
        return False

    if amount <= 0:
        return False

    expected_hash = coinbase_tx_hash(
        miner_pub,
        amount,
        created_at,
        height,
    )

    if coinbase.get("tx_hash") != expected_hash:
        return False

    return True

MAX_BLOCK_BYTES = 2_000_000
BLOCK_FIELDS = {"height", "prev_hash", "transactions", "nonce", "timestamp", "difficulty", "hash"}


def validate_block_size(block: dict) -> bool:
    """Protection contre les blocs gigantesques."""
    if not isinstance(block, dict):
        return False

    try:
        size = len(
            json.dumps(
                block,
                sort_keys=True,
                separators=(",", ":"),
            ).encode()
        )
    except Exception:
        return False

    return size <= MAX_BLOCK_BYTES


def is_valid_chain_payload(chain: list[dict]) -> bool:
    if not chain:
        return True

    for i, block in enumerate(chain):
        candidate = dict(block)
        incoming_hash = candidate.pop("hash", None)
        check_hash = block_hash_of(block)

        if check_hash != incoming_hash:
            return False

        # Genesis : pas de PoW obligatoire
        if i == 0:
            if int(block.get("height", -1)) != 0:
                return False

            if block.get("prev_hash") != "0":
                return False

            continue

        # Tous les autres blocs doivent respecter le PoW
        if not block_meets_target(
            incoming_hash,
            int(block["difficulty"]),
        ):
            return False

        if i == 0:
            if block["prev_hash"] != "0":
                return False
        else:
            if block["prev_hash"] != chain[i - 1]["hash"]:
                return False
    return True

def validate_block_transactions(db, block):
    """
    Vérifie les transactions d'un bloc.

    Les UTXO sont vérifiés contre la DB.
    Les doubles dépenses sont détectées à l'intérieur du bloc.
    """

    print(
        f"🔎 validate_block_transactions: "
        f"{len(block.get('transactions', []))} tx",
        flush=True,
    )

    temp_spent = set()
    txs = block.get("transactions", [])

    if not txs:
        return False

    for index, tx in enumerate(txs):

        # -----------------------------------------------------
        # Coinbase
        # -----------------------------------------------------

        if tx.get("sender_pub") == "NETWORK":

            # Coinbase obligatoirement première transaction
            if index != 0:
                return False

            continue

        sender_pub = tx.get("sender_pub")

        if not sender_pub:
            return False

        inputs = tx.get("inputs", [])
        outputs = tx.get("outputs", [])
        signature = tx.get("signature", "")

        if not inputs or not outputs:
            return False

        try:
            tx_created_at = int(tx.get("created_at"))
        except (TypeError, ValueError):
            return False

        if tx.get("tx_hash") != strict_tx_hash_of(
            sender_pub,
            inputs,
            outputs,
            signature,
            tx_created_at,
        ):
            return False

        total_in = 0
        total_out = 0

        # -----------------------------------------------------
        # Inputs
        # -----------------------------------------------------

        for txin in inputs:

            try:
                prev_tx_hash = txin["prev_tx_hash"]
                output_index = int(txin["output_index"])
            except (KeyError, TypeError, ValueError):
                return False

            ref = (
                prev_tx_hash,
                output_index,
            )

            # Double dépense dans le même bloc
            if ref in temp_spent:
                return False

            utxo = find_utxo(
                db,
                prev_tx_hash,
                output_index,
            )

            if not utxo:
                return False

            if utxo.spent:
                return False

            if utxo.recipient_pub != sender_pub:
                return False

            temp_spent.add(ref)

            total_in += int(utxo.amount)

        # -----------------------------------------------------
        # Outputs
        # -----------------------------------------------------

        for output in outputs:

            try:
                amount = int(output["amount"])
                recipient = output["recipient_pub"]
            except (KeyError, TypeError, ValueError):
                return False

            if amount <= 0:
                return False

            if not recipient:
                return False

            total_out += amount

        if total_in < total_out:
            return False

        fee = total_in - total_out

        # -----------------------------------------------------
        # Signature
        # -----------------------------------------------------

        if not verify_strict_signature(
            sender_pub,
            inputs,
            outputs,
            signature,
            fee,
        ):
            return False

    return True

_SUPPLY_CACHE = {"height": None, "supply": 0}


def real_supply(db) -> int:
    """
    Supply réelle = somme des récompenses coinbase
    présentes dans tous les blocs de la chaîne.
    Recalculée seulement quand la hauteur de la chaîne change.
    """

    tip = db.query(BlockModel.height).order_by(BlockModel.height.desc()).first()
    tip_height = int(tip[0]) if tip else -1

    if _SUPPLY_CACHE["height"] == tip_height:
        return _SUPPLY_CACHE["supply"]

    blocks = db.query(BlockModel).all()

    total = sum(
        int(tx.get("amount", 0))
        for b in blocks
        for tx in b.transactions
        if tx.get("sender_pub") == "NETWORK"
    )

    _SUPPLY_CACHE["height"] = tip_height
    _SUPPLY_CACHE["supply"] = total
    return total

def validate_block_full(db, block):
    """
    Validation consensus complète d'un bloc CMIA.
    """

    print(
        "🔎 validate_block_full APPELÉ",
        flush=True,
    )

    if not isinstance(block, dict):
        print(
            "❌ VALIDATION: block n'est pas un dict",
            flush=True,
        )
        return False

    if not validate_block_size(block):
        print("❌ BLOCK TOO LARGE OR UNREADABLE", flush=True)
        return False

    # Le hash couvre tous les champs du bloc, mais la base n'en stocke que ceux-ci.
    # Tout champ supplémentaire casserait la vérification du bloc par les autres noeuds.
    if set(block.keys()) != BLOCK_FIELDS:
        print(
            f"❌ BLOCK FIELDS: unexpected={sorted(set(block.keys()) ^ BLOCK_FIELDS)}",
            flush=True,
        )
        return False

    required = [
        "height",
        "prev_hash",
        "transactions",
        "nonce",
        "timestamp",
        "difficulty",
        "hash",
    ]

    missing = [
        field
        for field in required
        if field not in block
    ]

    if missing:
        print(
            f"❌ REQUIRED FIELDS: missing={missing}",
            flush=True,
        )
        return False

    try:
        height = int(block["height"])
        nonce = int(block["nonce"])
        timestamp = int(block["timestamp"])
        difficulty = int(block["difficulty"])
        block_hash = str(block["hash"])
        prev_hash = str(block["prev_hash"])
    except (
        TypeError,
        ValueError,
        OverflowError,
    ) as exc:
        print(
            f"❌ BLOCK FIELDS ERROR: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
        return False

    if height < 1:
        print(
            f"❌ HEIGHT INVALID: {height}",
            flush=True,
        )
        return False

    if nonce < 0:
        print(
            f"❌ NONCE INVALID: {nonce}",
            flush=True,
        )
        return False

    if not (
        MIN_DIFFICULTY
        <= difficulty
        <= MAX_DIFFICULTY
    ):
        print(
            f"❌ DIFFICULTY RANGE INVALID: {difficulty}",
            flush=True,
        )
        return False

    if len(block_hash) != 64:
        print(
            f"❌ HASH LENGTH INVALID: {len(block_hash)}",
            flush=True,
        )
        return False

    try:
        int(block_hash, 16)
    except ValueError:
        print(
            "❌ HASH HEX INVALID",
            flush=True,
        )
        return False

    # HASH
    calculated_hash = block_hash_of(block)

    if calculated_hash != block_hash:
        print(
            f"❌ HASH MISMATCH: "
            f"received={block_hash}, "
            f"calculated={calculated_hash}",
            flush=True,
        )
        return False

    # POW
    if not block_meets_target(
        block_hash,
        difficulty,
    ):
        print(
            f"❌ POW INVALID: difficulty={difficulty}",
            flush=True,
        )
        return False

    # CURRENT TIP
    last_block = (
        db.query(BlockModel)
        .order_by(
            BlockModel.height.desc()
        )
        .first()
    )

    if last_block is None:
        print(
            "❌ NO CURRENT TIP",
            flush=True,
        )
        return False

    expected_height = (
        int(last_block.height) + 1
    )

    if height != expected_height:
        print(
            f"❌ HEIGHT MISMATCH: "
            f"received={height}, "
            f"expected={expected_height}",
            flush=True,
        )
        return False

    # PREVIOUS HASH
    if prev_hash != str(last_block.hash):
        print(
            f"❌ PREV HASH MISMATCH: "
            f"received={prev_hash}, "
            f"expected={last_block.hash}",
            flush=True,
        )
        return False

    # DIFFICULTY
    expected_difficulty = (
        calculate_next_difficulty(
            db,
            height,
        )
    )

    if difficulty != expected_difficulty:
        print(
            f"❌ DIFFICULTY: "
            f"received={difficulty}, "
            f"expected={expected_difficulty}",
            flush=True,
        )
        return False

    # TIMESTAMP
    now = int(time.time())

    if timestamp > now + 60:
        print(
            f"❌ TIMESTAMP FUTURE: "
            f"timestamp={timestamp}, "
            f"now={now}",
            flush=True,
        )
        return False

    try:
        previous_timestamp = int(
            last_block.timestamp
        )
    except (
        TypeError,
        ValueError,
    ):
        print(
            "❌ PREVIOUS TIMESTAMP INVALID",
            flush=True,
        )
        return False

    if timestamp < previous_timestamp - 60:
        print(
            f"❌ TIMESTAMP OLD: "
            f"timestamp={timestamp}, "
            f"previous={previous_timestamp}",
            flush=True,
        )
        return False

    # TRANSACTIONS
    txs = block.get("transactions")

    if not isinstance(txs, list):
        print(
            "❌ TRANSACTIONS NOT A LIST",
            flush=True,
        )
        return False

    max_block_tx = int(
        globals().get(
            "MAX_BLOCK_TX",
            200,
        )
    )

    if len(txs) == 0:
        print(
            "❌ EMPTY TRANSACTIONS",
            flush=True,
        )
        return False

    if len(txs) > max_block_tx:
        print(
            f"❌ TOO MANY TRANSACTIONS: "
            f"{len(txs)} > {max_block_tx}",
            flush=True,
        )
        return False

    # COINBASE
    if not validate_coinbase(block):
        print(
            "❌ COINBASE INVALID",
            flush=True,
        )
        return False

    coinbase = txs[0]

    if coinbase.get("type") != "coinbase":
        print("❌ COINBASE TYPE INVALID", flush=True)
        return False

    if coinbase.get("sender_pub") != "NETWORK":
        print("❌ COINBASE SENDER INVALID", flush=True)
        return False

    if coinbase.get("network_id") != NETWORK_ID:
        print("❌ COINBASE NETWORK INVALID", flush=True)
        return False
        
    if not isinstance(coinbase, dict):
        print(
            "❌ COINBASE NOT A DICT",
            flush=True,
        )
        return False

    try:
        reward = int(
            coinbase.get(
                "amount",
                -1,
            )
        )
    except (
        TypeError,
        ValueError,
    ):
        print(
            "❌ COINBASE REWARD INVALID",
            flush=True,
        )
        return False

    expected_reward = (
        recalc_reward_for_height(
            height
        )
    )

    if reward != expected_reward:
        print(
            f"❌ REWARD: "
            f"received={reward}, "
            f"expected={expected_reward}",
            flush=True,
        )
        return False

    if reward <= 0:
        print("❌ COINBASE REWARD <= 0", flush=True)
        return False

    miner_pub = coinbase.get(
        "recipient_pub"
    )

    if not isinstance(
        miner_pub,
        str,
    ) or not miner_pub:
        print(
            "❌ MINER PUB INVALID",
            flush=True,
        )
        return False

    try:
        coinbase_created_at = int(
            coinbase.get("created_at")
        )
    except (
        TypeError,
        ValueError,
    ):
        print(
            "❌ COINBASE TIMESTAMP INVALID",
            flush=True,
        )
        return False

    expected_coinbase_hash = coinbase_tx_hash(
        miner_pub,
        reward,
        coinbase_created_at,
        height,
    )

    if coinbase.get("tx_hash") != expected_coinbase_hash:
        print(
            f"❌ COINBASE TX HASH INVALID: "
            f"received={coinbase.get('tx_hash')}, "
            f"expected={expected_coinbase_hash}",
            flush=True,
        )
        return False

    # MAX SUPPLY
    try:
        max_supply = int(
            os.getenv(
                "MAX_SUPPLY",
                "10000000",
            )
        )
    except ValueError:
        max_supply = 10_000_000

    try:
        supply = real_supply(db)
    except Exception as exc:
        print(
            f"❌ MAX SUPPLY CHECK ERROR: "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
        return False

    if supply + reward > max_supply:
        print(
            f"❌ MAX SUPPLY: "
            f"supply={supply}, "
            f"reward={reward}, "
            f"max={max_supply}",
            flush=True,
        )
        return False

    # TRANSACTIONS VALIDATION
    print(
        "🔎 Passage validation transactions...",
        flush=True,
    )

    if not validate_block_transactions(
        db,
        block,
    ):
        print(
            "❌ TRANSACTIONS INVALID",
            flush=True,
        )
        return False

    print(
        "✅ validate_block_full: ALL CHECKS PASSED",
        flush=True,
    )

    return True

def current_height(db) -> int:
    """Retourne la hauteur actuelle de la blockchain."""
    last_block = db.query(BlockModel).order_by(BlockModel.height.desc()).first()
    return last_block.height if last_block else -1

def last_block_hash(db) -> str:
    """Retourne le hash du dernier bloc inscrit."""
    last_block = db.query(BlockModel).order_by(BlockModel.height.desc()).first()
    return last_block.hash if last_block else "0"

def get_balance(db, public_key: str) -> int:
    """Calcule le solde disponible pour une clé publique via les UTXOs non dépensés."""
    utxos = (
        db.query(UTXOModel)
        .filter(UTXOModel.recipient_pub == public_key, UTXOModel.spent == False)
        .all()
    )
    return sum(u.amount for u in utxos)

def load_wallet_by_pub(db, public_key: str):
    """Charge un wallet depuis la base de données via sa clé publique."""
    return db.query(WalletModel).filter(WalletModel.public_key == public_key).first()

def decrypt_private_key_hex(encrypted_text: str) -> str:
    """Déchiffre une clé privée (alias de vault_decrypt pour compatibilité)."""
    from vault_client import vault_decrypt
    return vault_decrypt(encrypted_text)

def sign_message_with_private_hex(private_hex: str, message: str) -> str:
    """Signe le SHA-256 du message — symétrique de verify_strict_signature,
    qui vérifie via verify_digest(sha256(message))."""
    import hashlib
    from ecdsa import SigningKey
    sk = SigningKey.from_string(bytes.fromhex(private_hex), curve=SECP256k1)
    digest = hashlib.sha256(message.encode()).digest()
    return sk.sign_digest(digest).hex()

def find_utxo(db, prev_tx_hash: str, output_index: int):
    """Trouve un UTXO spécifique dans la base de données."""
    return (
        db.query(UTXOModel)
        .filter(UTXOModel.tx_hash == prev_tx_hash, UTXOModel.output_index == output_index)
        .first()
    )

def get_tx_inputs(db, tx_hash: str):
    """Récupère les inputs d'une transaction."""
    from db import TransactionInputModel
    return (
        db.query(TransactionInputModel)
        .filter(TransactionInputModel.tx_hash == tx_hash)
        .order_by(TransactionInputModel.id.asc())
        .all()
    )

def get_tx_outputs(db, tx_hash: str):
    """Récupère les outputs d'une transaction."""
    from db import TransactionOutputModel
    return (
        db.query(TransactionOutputModel)
        .filter(TransactionOutputModel.tx_hash == tx_hash)
        .order_by(TransactionOutputModel.output_index.asc())
        .all()
    )

def select_utxos_for_amount(db, sender_pub: str, amount: int):
    """Sélectionne les UTXOs nécessaires pour couvrir un montant de transaction."""
    from fastapi import HTTPException
    utxos = (
        db.query(UTXOModel)
        .filter(UTXOModel.recipient_pub == sender_pub, UTXOModel.spent == False)
        .order_by(UTXOModel.id.asc())
        .all()
    )

    selected = []
    total = 0
    for u in utxos:
        selected.append(u)
        total += int(u.amount)
        if total >= amount:
            break

    if total < amount:
        raise HTTPException(status_code=400, detail="Solde insuffisant")

    return selected, total

def is_input_reserved_in_mempool(db, prev_tx_hash: str, output_index: int, excluding_tx_hash: str | None = None) -> bool:
    """Vérifie si un UTXO est déjà bloqué par une transaction en attente dans la mempool."""
    from db import TransactionInputModel, TransactionModel
    q = (
        db.query(TransactionInputModel, TransactionModel)
        .join(TransactionModel, TransactionInputModel.tx_hash == TransactionModel.tx_hash)
        .filter(
            TransactionInputModel.prev_tx_hash == prev_tx_hash,
            TransactionInputModel.output_index == output_index,
            TransactionModel.status == "pending",
        )
    )
    if excluding_tx_hash:
        q = q.filter(TransactionInputModel.tx_hash != excluding_tx_hash)
    return q.first() is not None

def validate_strict_transaction(
    db,
    sender_pub: str,
    inputs: list[dict],
    outputs: list[dict],
    signature: str,
    tx_hash: str | None = None,
):
    """Valide la cohérence d'une transaction stricte (montants et UTXOs)."""
    from fastapi import HTTPException
    if not inputs: raise HTTPException(status_code=400, detail="Transaction sans inputs")
    if not outputs: raise HTTPException(status_code=400, detail="Transaction sans outputs")

    seen_inputs = set()
    total_in = 0

    for txin in inputs:
        ref = (txin["prev_tx_hash"], txin["output_index"])
        if ref in seen_inputs: raise HTTPException(status_code=400, detail="Input dupliqué")
        seen_inputs.add(ref)

        utxo = find_utxo(db, txin["prev_tx_hash"], txin["output_index"])
        if not utxo: raise HTTPException(status_code=400, detail="UTXO introuvable")
        if utxo.spent: raise HTTPException(status_code=400, detail="UTXO déjà dépensé")
        if utxo.recipient_pub != sender_pub: raise HTTPException(status_code=400, detail="UTXO non possédé par le sender")
        if is_input_reserved_in_mempool(db, txin["prev_tx_hash"], txin["output_index"], excluding_tx_hash=tx_hash):
            raise HTTPException(status_code=400, detail="UTXO déjà réservé dans la mempool")

        total_in += int(utxo.amount)

    total_out = sum(int(out["amount"]) for out in outputs if int(out["amount"]) > 0)
    if total_in < total_out: raise HTTPException(status_code=400, detail="Inputs insuffisants")

    fee = total_in - total_out
    if not verify_strict_signature(sender_pub, inputs, outputs, signature, fee):
        raise HTTPException(status_code=400, detail="Signature stricte invalide")

    return {"total_in": total_in, "total_out": total_out, "fee": fee}

def normalize_tx_inputs(inputs: list[dict]) -> list[dict]:
    return [{"prev_tx_hash": i["prev_tx_hash"], "output_index": int(i["output_index"]), "signature": i["signature"]} for i in inputs]

def normalize_tx_outputs(outputs: list[dict]) -> list[dict]:
    return [{"recipient_pub": o["recipient_pub"], "amount": int(o["amount"])} for o in outputs]

def json_size_bytes(obj: dict | list) -> int:
    return len(json.dumps(obj, sort_keys=True).encode())

def mempool_size(db) -> int:
    return db.query(TransactionModel).filter(TransactionModel.status == "pending").count()

def sender_pending_count(db, sender_pub: str) -> int:
    return db.query(TransactionModel).filter(TransactionModel.status == "pending", TransactionModel.sender_pub == sender_pub).count()

GENESIS_MESSAGE = "CryptomonnaiesIA Network â€” A public blockchain infrastructure layer for next-generation digital value"


def build_genesis_block(message: str = None) -> dict:
    """Construit le bloc Genesis. Son hash dépend du texte exact du message."""
    genesis_timestamp = GENESIS_TIMESTAMP

    block = {
        "height": 0,
        "prev_hash": "0",
        "transactions": [
            {
                "tx_hash": "genesis",
                "sender_pub": "NETWORK",
                "recipient_pub": "GENESIS",
                "amount": 0,
                "signature": "",
                "created_at": genesis_timestamp,
                "type": "genesis",
                "tx_version": TX_VERSION,
                "network_id": NETWORK_ID,
                "message": GENESIS_MESSAGE if message is None else message,
            }
        ],
        "nonce": 0,
        "timestamp": genesis_timestamp,
        "difficulty": MIN_DIFFICULTY,
    }
    block["hash"] = block_hash_of(block)
    return block


def create_genesis_block(db):
    """Initialise le bloc Genesis (bloc 0) si la blockchain est vide."""
    if current_height(db) >= 0:
        return

    block = build_genesis_block()
    genesis_timestamp = block["timestamp"]

    db.add(
        BlockModel(
            height=0,
            hash=block["hash"],
            prev_hash="0",
            nonce=0,
            timestamp=genesis_timestamp,
            difficulty=block["difficulty"],
            transactions=block["transactions"],
        )
    )
    db.commit()
    print("🚀 Bloc Genesis créé avec succès !")

def calculate_next_difficulty(db, next_height: int) -> int:
    """
    Calcule la difficulté de consensus du prochain bloc.

    Ajustement tous les 5 blocs.
    Objectif : 30 secondes par bloc.

    Exemple :
        blocs 0 -> 5
        on mesure le temps réel
        puis la difficulté du bloc 6 est ajustée.
    """

    next_height = int(next_height)

    # Genesis
    if next_height <= 1:
        return MIN_DIFFICULTY

    last_block = (
        db.query(BlockModel)
        .order_by(BlockModel.height.desc())
        .first()
    )

    if not last_block:
        return MIN_DIFFICULTY

    current_difficulty = int(last_block.difficulty)

    # Pas d'ajustement
    if next_height % DIFFICULTY_ADJUST_EVERY_BLOCKS != 1:
        return current_difficulty

    current_height_value = next_height - 1

    current_block = (
        db.query(BlockModel)
        .filter(BlockModel.height == current_height_value)
        .first()
    )

    old_height = current_height_value - DIFFICULTY_ADJUST_EVERY_BLOCKS

    old_block = (
        db.query(BlockModel)
        .filter(BlockModel.height == old_height)
        .first()
    )

    if not current_block or not old_block:
        return current_difficulty

    actual_time = int(current_block.timestamp) - int(old_block.timestamp)

    if actual_time <= 0:
        actual_time = 1

    expected_time = (
        DIFFICULTY_ADJUST_EVERY_BLOCKS
        * TARGET_BLOCK_TIME_SECONDS
    )

    ratio = actual_time / expected_time

    # Empêche un changement catastrophique en un seul ajustement.
    ratio = max(0.25, min(4.0, ratio))

    # Si les blocs arrivent trop vite :
    # augmentation de la difficulté.
    if ratio < 1.0:
        change = max(1, int(round(-math.log2(ratio))))
        new_difficulty = current_difficulty + change

    # Si les blocs arrivent trop lentement :
    # diminution de la difficulté.
    elif ratio > 1.0:
        change = max(1, int(round(math.log2(ratio))))
        new_difficulty = current_difficulty - change

    else:
        new_difficulty = current_difficulty

    return max(
        MIN_DIFFICULTY,
        min(MAX_DIFFICULTY, new_difficulty),
    )


