#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

[ -f .env ] || cp .env.example .env
[ -d venv ] || python3 -m venv venv
. venv/bin/activate
pip install -r requirements.txt
exec python main.py
