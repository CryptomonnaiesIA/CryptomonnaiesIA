"""
Compare le bloc Genesis de CE code avec celui d'un nœud en ligne.

    python check_genesis.py                       # nœud local http://localhost:8000
    python check_genesis.py https://api.cryptomonnaiesia.com

Un nœud ne peut suivre une chaîne que si son Genesis est identique : le hash du
Genesis dépend du texte exact du message qu'il contient.
"""
import sys

import requests

from core.blockchain import GENESIS_MESSAGE, build_genesis_block

url = (sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000").rstrip("/")

r = requests.get(f"{url}/chain", params={"from_height": 0, "limit": 1}, timeout=15)
r.raise_for_status()
online = r.json()["blocks"][0]
online_msg = online["transactions"][0].get("message")

mine = build_genesis_block()
print("Genesis en ligne :", online["hash"])
print("Genesis du code  :", mine["hash"])

if mine["hash"] == online["hash"]:
    print("OK : identique, ce code peut suivre cette chaîne.")
else:
    fixed = build_genesis_block(online_msg)
    if fixed["hash"] == online["hash"]:
        print("DIFFÉRENT, mais le Genesis en ligne correspond à ce message :")
        print(repr(online_msg))
        print("Remplacez la valeur de GENESIS_MESSAGE dans core/blockchain.py par ce texte exact.")
    else:
        print("DIFFÉRENT : autre réseau, autre horodatage ou autre NETWORK_ID.")
    sys.exit(1)
