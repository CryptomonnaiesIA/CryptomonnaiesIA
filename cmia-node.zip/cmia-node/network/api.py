from dotenv import load_dotenv
load_dotenv()

import sys
from pathlib import Path
import os
import json
import time
import hmac
import hashlib
import datetime
import uuid
from typing import Optional, List

from fastapi import FastAPI, Header, HTTPException, Depends, Response, Request, APIRouter
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import desc
from sqlalchemy.orm import Session

# --- Importations locales ---
from db import (
    init_db, SessionLocal, get_db, WalletModel, BlockModel, TransactionModel,
    TransactionInputModel, TransactionOutputModel, UTXOModel, NetworkStateModel,
    OrderModel, MarketData, SignalModel, MinerModel
)
from vault_client import vault_encrypt, vault_decrypt 
from miners_registry import touch_miner, mark_block_mined, compute_miner_stats, miners_registry


# from workers.telegram_bot import send_cmia_signal

# --- Importations des briques que nous venons de créer ---
from core.blockchain import (
    now_ts,
    tx_hash_of,
    coinbase_tx_hash,
    block_hash_of,
    strict_tx_hash_of,
    recalc_reward_for_height,
    difficulty_to_target,
    calculate_next_difficulty,
    verify_strict_signature,
    mine_pow,
    validate_block_full,
    is_valid_chain_payload,
    block_meets_target,
    current_height,
    last_block_hash,
    get_balance,
    load_wallet_by_pub,
    decrypt_private_key_hex,
    sign_message_with_private_hex,
    find_utxo,
    get_tx_inputs,
    get_tx_outputs,
    select_utxos_for_amount,
    is_input_reserved_in_mempool,
    spending_intent_message,
    create_genesis_block,
    validate_strict_transaction,
    normalize_tx_inputs,
    normalize_tx_outputs,
    json_size_bytes,
    mempool_size,
    sender_pending_count,
    validate_block_transactions,
)
from ecdsa import VerifyingKey, SECP256k1
from network.p2p import p2p_broadcast_tx, p2p_broadcast_block

# ================== INITIALISATION DE L'API ==================
# docs/redoc/openapi fermés : la carte de l'API n'est plus publique.
app = FastAPI(title="CMIA Node API", docs_url=None, redoc_url=None, openapi_url=None)
router = APIRouter()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://www.cryptomonnaiesia.com", "https://cryptomonnaiesia.com"],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "X-Admin-Key", "X-CMIA-Timestamp", "X-CMIA-Nonce", "X-CMIA-Signature", "Authorization"],
)

# ---------------------------------------------------------------------------
# DURCISSEMENT SÉCURITÉ (middlewares, exécutés à chaque requête)
# ---------------------------------------------------------------------------
import time as _time
from collections import deque as _deque
from fastapi import Request as _Request
from fastapi.responses import JSONResponse as _JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware as _BaseHTTPMiddleware

# 1. Rate-limiting maison : N requêtes / fenêtre / IP. Sans dépendance externe.
_RATE_MAX = int(os.getenv("RATE_MAX", "120"))          # requêtes autorisées
_RATE_WINDOW = int(os.getenv("RATE_WINDOW", "60"))    # par fenêtre (secondes)
_RATE_HITS = {}   # ip -> deque de timestamps

# 2. Chemins de scan connus : on répond 404 immédiatement sans toucher au code métier.
_SCAN_BLOCKLIST = (
    ".env", ".git", ".aws", ".ssh", "wp-admin", "wp-content", "wp-includes",
    "phpinfo", "stripe", "/admin.php", "credentials", ".backup", ".sql",
    "/cgi-bin", "/vendor/", ".php", "/.well-known/", "eval-stdin",
)

def _client_ip(request):
    # Derrière le tunnel Cloudflare : privilégier l'en-tête forwarded si présent.
    fwd = request.headers.get("cf-connecting-ip") or request.headers.get("x-forwarded-for")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else "unknown"

@app.middleware("http")
async def _security_middleware(request: _Request, call_next):
    path = request.url.path.lower()

    # -- Blocage des scans : réponse 404 sèche, aucune logique métier atteinte --
    if any(bad in path for bad in _SCAN_BLOCKLIST):
        return _JSONResponse(status_code=404, content={"detail": "Not Found"})

    # -- Rate-limiting par IP --
    # Appels internes (P2P, synchronisation) : TCP local, jamais derrière un proxy.
    internal = (
        request.client is not None
        and request.client.host in ("127.0.0.1", "::1")
        and not request.headers.get("cf-connecting-ip")
        and not request.headers.get("x-forwarded-for")
    )
    if not internal:
        ip = _client_ip(request)
        now = _time.time()
        if len(_RATE_HITS) > 50000:
            _RATE_HITS.clear()
        dq = _RATE_HITS.get(ip)
        if dq is None:
            dq = _deque()
            _RATE_HITS[ip] = dq
        while dq and dq[0] < now - _RATE_WINDOW:
            dq.popleft()
        if len(dq) >= _RATE_MAX:
            return _JSONResponse(status_code=429, content={"detail": "Trop de requetes, ralentis."})
        dq.append(now)

    # -- Traitement normal, avec masquage des erreurs internes --
    try:
        response = await call_next(request)
    except Exception:
        # Jamais de traceback exposee au client.
        return _JSONResponse(status_code=500, content={"detail": "Erreur interne"})

    # -- En-tetes de securite sur toutes les reponses --
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Cache-Control"] = "no-store"
    return response

# Configuration via variables d'environnement
NODE_PORT = int(os.getenv("NODE_PORT", "8000"))
DIFFICULTY = int(os.getenv("DIFFICULTY", "3"))
MAX_SUPPLY = int(os.getenv("MAX_SUPPLY", "10000000"))
INITIAL_REWARD = int(os.getenv("INITIAL_REWARD", "25"))
HALVING_EVERY_BLOCKS = int(os.getenv("HALVING_EVERY_BLOCKS", "5000"))
NETWORK_NAME = os.getenv("NETWORK_NAME", "CMIA Network")
NETWORK_ID = os.getenv("NETWORK_ID", "cmia-mainnet-v1")
SYMBOL = os.getenv("SYMBOL", "CMIA")
TX_VERSION = int(os.getenv("TX_VERSION", "1"))
MAX_BLOCK_TX = int(os.getenv("MAX_BLOCK_TX", "200"))
MAX_MEMPOOL_TX = int(os.getenv("MAX_MEMPOOL_TX", "5000"))
MAX_TX_PER_SENDER_IN_MEMPOOL = int(os.getenv("MAX_TX_PER_SENDER_IN_MEMPOOL", "50"))
MAX_TX_BYTES = int(os.getenv("MAX_TX_BYTES", "25000"))
FAUCET_PUBLIC_KEY = os.getenv("FAUCET_PUBLIC_KEY", "")
FAUCET_PRIVATE_KEY = os.getenv("FAUCET_PRIVATE_KEY", "")
FAUCET_AMOUNT = int(os.getenv("FAUCET_AMOUNT", "10"))
TREASURY_API_SECRET = os.environ.get("TREASURY_API_SECRET")
TREASURY_PUBLIC_KEY = os.environ.get("TREASURY_PUBLIC_KEY")
TREASURY_PRIVATE_KEY = os.environ.get("TREASURY_PRIVATE_KEY")

# --- Accès administrateur ---
# Les routes qui manipulent des clés gérées par le nœud exigent l'en-tête X-Admin-Key.
# Sans ADMIN_API_SECRET dans l'environnement, ces routes sont fermées pour tout le monde.
ADMIN_API_SECRET = os.getenv("ADMIN_API_SECRET", "")

def require_admin(x_admin_key: str = Header(default="")):
    if not ADMIN_API_SECRET or not hmac.compare_digest(x_admin_key.encode(), ADMIN_API_SECRET.encode()):
        raise HTTPException(status_code=403, detail="Unauthorized")

SEEN_TX = set()
SEEN_BLOCKS = set()

class MiningTemplateRequest(BaseModel):
    miner_pub: str

class MiningSubmitRequest(BaseModel):
    block: dict

class SendStrictTxRequest(BaseModel):
    sender_pub: str
    recipient_pub: str
    amount: int

class TreasurySendRequest(BaseModel):
    recipient_pub: str
    amount: int
    
class CreateOrderRequest(BaseModel):
    cmia_address: str
    btc_address: str
    expected_btc: str
    expected_cmia: str
    expires_in_seconds: int = 3600

class CompleteOrderRequest(BaseModel):
    btc_txid: str

class FaucetRequest(BaseModel):
    recipient_pub: str

# ================== ROUTE / UTILS LOCALES ==================
def get_current_difficulty(db) -> int:
    last_block = db.query(BlockModel).order_by(BlockModel.height.desc()).first()
    return int(last_block.difficulty) if last_block else DIFFICULTY
    
def real_supply(db) -> int:
    """Supply réelle (voir core.blockchain.real_supply, mise en cache par hauteur)."""
    from core.blockchain import real_supply as _real_supply
    return _real_supply(db)


def get_or_create_network_state(db: Session):
    state = db.query(NetworkStateModel).filter(NetworkStateModel.id == 1).first()
    if not state:
        state = NetworkStateModel(
            id=1,
            # On retire "height=0" car la colonne n'existe pas dans ton modèle DB
            coins_minted=0,
            current_reward=INITIAL_REWARD,
            max_supply=MAX_SUPPLY,
            halving_every_blocks=HALVING_EVERY_BLOCKS,
        )
        db.add(state)
        db.commit()
        db.refresh(state)
    return state
    


def apply_block_utxos(db: Session, block_transactions: list, block_hash: str):
    """
    Applique les effets UTXO de toutes les transactions d'un bloc.
    """

    for tx in block_transactions:
        tx_hash = tx.get("tx_hash")

        if not tx_hash:
            continue

        # =========================================================
        # COINBASE
        # =========================================================
        if tx.get("sender_pub") == "NETWORK":
            amount = int(tx.get("amount", 0))

            if amount <= 0:
                continue

            existing = (
                db.query(UTXOModel)
                .filter(
                    UTXOModel.tx_hash == tx_hash,
                    UTXOModel.output_index == 0,
                )
                .first()
            )

            if existing:
                continue

            db.add(
                UTXOModel(
                    tx_hash=tx_hash,
                    output_index=0,
                    recipient_pub=tx["recipient_pub"],
                    amount=amount,
                    spent=False,
                )
            )

            continue

        # =========================================================
        # TRANSACTION NORMALE
        # =========================================================

        inputs = tx.get("inputs", [])
        outputs = tx.get("outputs", [])

        # Dépenser les UTXO d'entrée
        for txin in inputs:
            prev_tx_hash = txin.get("prev_tx_hash")
            output_index = int(txin.get("output_index", 0))

            if not prev_tx_hash:
                continue

            utxo = (
                db.query(UTXOModel)
                .filter(
                    UTXOModel.tx_hash == prev_tx_hash,
                    UTXOModel.output_index == output_index,
                )
                .first()
            )

            if utxo and not utxo.spent:
                utxo.spent = True
                utxo.spent_by_tx_hash = tx_hash

        # Créer les nouveaux UTXO
        for idx, out in enumerate(outputs):
            recipient_pub = out.get("recipient_pub")
            amount = int(out.get("amount", 0))

            if not recipient_pub or amount <= 0:
                continue

            existing = (
                db.query(UTXOModel)
                .filter(
                    UTXOModel.tx_hash == tx_hash,
                    UTXOModel.output_index == idx,
                )
                .first()
            )

            if existing:
                continue

            db.add(
                UTXOModel(
                    tx_hash=tx_hash,
                    output_index=idx,
                    recipient_pub=recipient_pub,
                    amount=amount,
                    spent=False,
                )
            )

        # Marquer la transaction comme confirmée
        row = (
            db.query(TransactionModel)
            .filter(TransactionModel.tx_hash == tx_hash)
            .first()
        )

        if row:
            row.status = "confirmed"
            row.block_hash = block_hash
            
def recompute_network_state(db: Session):
    """Remet l'état réseau (supply, récompense) en cohérence avec la chaîne stockée."""
    state = get_or_create_network_state(db)
    last = db.query(BlockModel).order_by(BlockModel.height.desc()).first()
    height = int(last.height) if last else -1
    state.coins_minted = real_supply(db)
    state.current_reward = recalc_reward_for_height(height + 1)
    db.commit()
    return state


# ================== ENDPOINTS WALLET ==================
@app.post("/wallet/create", dependencies=[Depends(require_admin)])
def api_create_wallet(name: str, db: Session = Depends(get_db)):
    from core.blockchain import SigningKey, SECP256k1
    key = SigningKey.generate(curve=SECP256k1)
    public_key = key.get_verifying_key().to_string().hex()
    private_hex = key.to_string().hex()
    encrypted = vault_encrypt(private_hex)

    if db.query(WalletModel).filter(WalletModel.public_key == public_key).first():
        raise HTTPException(status_code=400, detail="Wallet déjà existant")

    row = WalletModel(name=name, public_key=public_key, private_encrypted=encrypted, created_at=now_ts())
    db.add(row)
    db.commit()
    return {"name": name, "address": public_key, "private_encrypted": encrypted}

@app.get("/wallets", dependencies=[Depends(require_admin)])
def api_wallets(db: Session = Depends(get_db)):
    rows = db.query(WalletModel).order_by(WalletModel.id.asc()).all()
    return [{"id": w.id, "name": w.name, "public_key": w.public_key, "created_at": w.created_at, "balance": get_balance(db, w.public_key)} for w in rows]

# ================== ENDPOINTS TRANSACTIONS & MEMPOOL ==================
@app.get("/mempool")
def api_mempool(db: Session = Depends(get_db)):
    rows = db.query(TransactionModel).filter(TransactionModel.status == "pending").order_by(TransactionModel.created_at.asc()).all()
    return [{
        "tx_hash": t.tx_hash, "sender_pub": t.sender_pub, "signature": t.signature, "status": t.status, "created_at": t.created_at,
        "inputs": [{"prev_tx_hash": i.prev_tx_hash, "output_index": i.output_index, "signature": i.signature} for i in get_tx_inputs(db, t.tx_hash)],
        "outputs": [{"output_index": o.output_index, "recipient_pub": o.recipient_pub, "amount": o.amount} for o in get_tx_outputs(db, t.tx_hash)]
    } for t in rows]

@app.post("/transaction/send-strict", dependencies=[Depends(require_admin)])
def api_send_strict_transaction(req: SendStrictTxRequest, db: Session = Depends(get_db)):
    if req.amount <= 0 or req.sender_pub == req.recipient_pub:
        raise HTTPException(status_code=400, detail="Paramètres invalides")
    
    wallet = db.query(WalletModel).filter(WalletModel.public_key == req.sender_pub).first()
    if not wallet: raise HTTPException(status_code=404, detail="Wallet introuvable")

    selected_utxos, total_in = select_utxos_for_amount(db, req.sender_pub, req.amount)
    inputs_unsigned = [{"prev_tx_hash": u.tx_hash, "output_index": u.output_index} for u in selected_utxos]
    outputs = [{"recipient_pub": req.recipient_pub, "amount": req.amount}]
    
    change = total_in - req.amount
    if change > 0: outputs.append({"recipient_pub": req.sender_pub, "amount": change})
    
    fee = total_in - sum(int(o["amount"]) for o in outputs)
    private_hex = vault_decrypt(wallet.private_encrypted)
    message = spending_intent_message(NETWORK_ID, TX_VERSION, req.sender_pub, inputs_unsigned, outputs, fee)
    signature = sign_message_with_private_hex(private_hex, message)
    
    inputs = [{"prev_tx_hash": u.tx_hash, "output_index": u.output_index, "signature": signature} for u in selected_utxos]
    created_at = now_ts()
    tx_hash = strict_tx_hash_of(req.sender_pub, inputs, outputs, signature, created_at)

    validate_strict_transaction(db, req.sender_pub, inputs, outputs, signature)
    
    row = TransactionModel(tx_hash=tx_hash, sender_pub=req.sender_pub, recipient_pub=req.recipient_pub, amount=req.amount, signature=signature, status="pending", created_at=created_at)
    db.add(row)
    for txin in inputs:
        db.add(TransactionInputModel(tx_hash=tx_hash, prev_tx_hash=txin["prev_tx_hash"], output_index=txin["output_index"], signature=txin["signature"]))
    for idx, out in enumerate(outputs):
        db.add(TransactionOutputModel(tx_hash=tx_hash, output_index=idx, recipient_pub=out["recipient_pub"], amount=int(out["amount"])))
    db.commit()

    tx_payload = {"tx_hash": tx_hash, "sender_pub": req.sender_pub, "tx_version": TX_VERSION, "network_id": NETWORK_ID, "inputs": inputs, "outputs": outputs, "signature": signature, "created_at": created_at}
    p2p_broadcast_tx(tx_payload)
    return {"status": "transaction_created", "tx_hash": tx_hash}




@app.post("/treasury/send")
def api_treasury_send(
    req: TreasurySendRequest,
    db: Session = Depends(get_db),
    x_admin_key: str = Header(...),
):
    admin_secret = os.getenv("TREASURY_API_SECRET")
    if not admin_secret or not hmac.compare_digest(x_admin_key, admin_secret):
        raise HTTPException(status_code=403, detail="Unauthorized")

    treasury_pub = os.getenv("TREASURY_WALLET_PUB")
    if not treasury_pub:
        raise HTTPException(status_code=500, detail="TREASURY_WALLET_PUB non configurée")

    if req.amount <= 0 or req.recipient_pub == treasury_pub:
        raise HTTPException(status_code=400, detail="Paramètres invalides")

    wallet = db.query(WalletModel).filter(WalletModel.public_key == treasury_pub).first()
    if not wallet:
        raise HTTPException(status_code=500, detail="Wallet de trésorerie introuvable en base")

    selected_utxos, total_in = select_utxos_for_amount(db, treasury_pub, req.amount)
    inputs_unsigned = [{"prev_tx_hash": u.tx_hash, "output_index": u.output_index} for u in selected_utxos]
    outputs = [{"recipient_pub": req.recipient_pub, "amount": req.amount}]

    change = total_in - req.amount
    if change > 0:
        outputs.append({"recipient_pub": treasury_pub, "amount": change})

    fee = total_in - sum(int(o["amount"]) for o in outputs)
    private_hex = vault_decrypt(wallet.private_encrypted)
    message = spending_intent_message(NETWORK_ID, TX_VERSION, treasury_pub, inputs_unsigned, outputs, fee)
    signature = sign_message_with_private_hex(private_hex, message)

    inputs = [{"prev_tx_hash": u.tx_hash, "output_index": u.output_index, "signature": signature} for u in selected_utxos]
    created_at = now_ts()
    tx_hash = strict_tx_hash_of(treasury_pub, inputs, outputs, signature, created_at)

    validate_strict_transaction(db, treasury_pub, inputs, outputs, signature)

    row = TransactionModel(tx_hash=tx_hash, sender_pub=treasury_pub, recipient_pub=req.recipient_pub, amount=req.amount, signature=signature, status="pending", created_at=created_at)
    db.add(row)
    for txin in inputs:
        db.add(TransactionInputModel(tx_hash=tx_hash, prev_tx_hash=txin["prev_tx_hash"], output_index=txin["output_index"], signature=txin["signature"]))
    for idx, out in enumerate(outputs):
        db.add(TransactionOutputModel(tx_hash=tx_hash, output_index=idx, recipient_pub=out["recipient_pub"], amount=int(out["amount"])))
    db.commit()

    p2p_broadcast_tx({"tx_hash": tx_hash, "sender_pub": treasury_pub, "tx_version": TX_VERSION, "network_id": NETWORK_ID, "inputs": inputs, "outputs": outputs, "signature": signature, "created_at": created_at})

    return {"status": "treasury_transaction_created", "tx_hash": tx_hash}



# ================== INFRASTRUCTURE & READ-ONLY API ==================
@app.get("/chain")
def api_chain(
    from_height: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
):
    """
    Synchronisation paginée de la blockchain.

    Exemple :
        /chain?from_height=1&limit=100

    Retourne au maximum 100 blocs à partir de la hauteur demandée.
    """

    try:
        from_height = int(from_height)
        limit = int(limit)
    except (TypeError, ValueError):
        raise HTTPException(
            status_code=400,
            detail="from_height et limit doivent être des entiers",
        )

    if from_height < 0:
        raise HTTPException(
            status_code=400,
            detail="from_height invalide",
        )

    # Protection contre les réponses gigantesques
    limit = min(max(limit, 1), 100)

    blocks = (
        db.query(BlockModel)
        .filter(BlockModel.height >= from_height)
        .order_by(BlockModel.height.asc())
        .limit(limit)
        .all()
    )

    return {
        "network_id": NETWORK_ID,
        "from_height": from_height,
        "limit": limit,
        "count": len(blocks),
        "blocks": [
            {
                "height": int(b.height),
                "hash": b.hash,
                "prev_hash": b.prev_hash,
                "nonce": int(b.nonce),
                "timestamp": int(b.timestamp),
                "difficulty": int(b.difficulty),
                "transactions": b.transactions,
            }
            for b in blocks
        ],
    }

@app.get("/")
def read_root():
    return {"status": "CMIA Node Online", "version": "1.0.0"}

app.include_router(router)


    
@app.get("/state")
def api_state(response: Response, db: Session = Depends(get_db)):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"

    last_block = (
        db.query(BlockModel)
        .order_by(BlockModel.height.desc())
        .first()
    )

    height = int(last_block.height) if last_block else -1

    return {
        "coins_minted": real_supply(db),
        "current_reward": recalc_reward_for_height(height + 1),
        "height": height,
        "status": "online",
    }


@app.get("/info")
async def api_info(db: Session = Depends(get_db)):
    last_block = (
        db.query(BlockModel)
        .order_by(BlockModel.height.desc())
        .first()
    )

    height = int(last_block.height) if last_block else -1
    stats = compute_miner_stats()

    return {
        "network": NETWORK_NAME,
        "network_id": NETWORK_ID,
        "symbol": SYMBOL,
        "difficulty": int(get_current_difficulty(db)),
        "height": height,
        "next_height": height + 1,
        "current_reward": recalc_reward_for_height(height + 1),
        "coins_minted": real_supply(db),
        "max_supply": MAX_SUPPLY,
        "total_registered": stats["total_registered"],
        "active_15m": stats["active_15m"],
        "active_24h": stats["active_24h"],
    }


@app.get("/miners")
async def api_get_miners(db: Session = Depends(get_db)):
    stats = compute_miner_stats()
    top = (
        db.query(MinerModel)
        .order_by(MinerModel.blocks_mined.desc())
        .limit(20)
        .all()
    )
    stats["top"] = [
        {
            "miner_pub": m.miner_pub,
            "blocks_mined": int(m.blocks_mined or 0),
            "total_reward": float(m.total_reward or 0.0),
        }
        for m in top
    ]
    return stats
    
@app.get("/balance/{public_key}")
def api_balance(public_key: str, db: Session = Depends(get_db)):
    utxos = (
        db.query(UTXOModel)
        .filter(UTXOModel.recipient_pub == public_key, UTXOModel.spent == False)
        .all()
    )
    return {
        "public_key": public_key,
        "balance": sum(int(u.amount) for u in utxos),
        "utxo_count": len(utxos),
    }

# ===========================================================================
# ENDPOINTS RÉSEAU P2P (Réception et propagation réseau)
# ===========================================================================

@app.post("/transaction/receive")
def api_receive_transaction(tx_payload: dict, db: Session = Depends(get_db)):
    """
    Reçoit une transaction en provenance d'un pair du réseau P2P,
    la valide et la propage aux autres nœuds si elle n'a pas encore été vue.
    """
    tx_hash = tx_payload.get("tx_hash")
    if not tx_hash:
        raise HTTPException(status_code=400, detail="tx_hash manquant")

    # 1. Éviter les boucles de réémission (idempotence P2P)
    if tx_hash in SEEN_TX:
        return {"status": "already_seen"}

    # Vérifier aussi si elle existe déjà dans la base de données
    existing = db.query(TransactionModel).filter(TransactionModel.tx_hash == tx_hash).first()
    if existing:
        SEEN_TX.add(tx_hash)
        return {"status": "already_exists"}

    sender_pub = tx_payload.get("sender_pub")
    inputs = tx_payload.get("inputs", [])
    outputs = tx_payload.get("outputs", [])
    signature = tx_payload.get("signature", "")
    created_at = tx_payload.get("created_at", now_ts())

    # Limites anti-spam (réseau ouvert) et cohérence du tx_hash
    if json_size_bytes(tx_payload) > MAX_TX_BYTES:
        raise HTTPException(status_code=413, detail="Transaction trop volumineuse")
    if mempool_size(db) >= MAX_MEMPOOL_TX:
        raise HTTPException(status_code=503, detail="Mempool pleine")
    if sender_pub and sender_pending_count(db, sender_pub) >= MAX_TX_PER_SENDER_IN_MEMPOOL:
        raise HTTPException(status_code=429, detail="Trop de transactions en attente pour cet expéditeur")
    try:
        created_at = int(created_at)
        expected_tx_hash = strict_tx_hash_of(sender_pub, inputs, outputs, signature, created_at)
    except (TypeError, ValueError, KeyError):
        raise HTTPException(status_code=400, detail="Transaction mal formée")
    if tx_hash != expected_tx_hash:
        raise HTTPException(status_code=400, detail="tx_hash invalide")

    # 2. Validation stricte de la transaction (UTXO, signature, montants)
    try:
        validate_strict_transaction(db, sender_pub, inputs, outputs, signature)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Transaction invalide: {str(e)}")

    # 3. Enregistrement dans la mempool locale
    row = TransactionModel(
        tx_hash=tx_hash,
        sender_pub=sender_pub,
        recipient_pub=outputs[0]["recipient_pub"] if outputs else "",
        amount=sum(int(o["amount"]) for o in outputs),
        signature=signature,
        status="pending",
        created_at=created_at,
    )
    db.add(row)

    for txin in inputs:
        db.add(
            TransactionInputModel(
                tx_hash=tx_hash,
                prev_tx_hash=txin["prev_tx_hash"],
                output_index=txin["output_index"],
                signature=txin.get("signature", signature),
            )
        )

    for idx, out in enumerate(outputs):
        db.add(
            TransactionOutputModel(
                tx_hash=tx_hash,
                output_index=idx,
                recipient_pub=out["recipient_pub"],
                amount=int(out["amount"]),
            )
        )

    db.commit()
    SEEN_TX.add(tx_hash)

    # 4. Re-propagation aux autres pairs du réseau
    p2p_broadcast_tx(tx_payload)

    return {"status": "transaction_accepted", "tx_hash": tx_hash}


@app.on_event("startup")
def startup_event():
    init_db()
    db = SessionLocal()
    try:
        create_genesis_block(db)
    finally:
        db.close()

# ================== MINAGE PUBLIC (le PoW est calculé par le mineur) ==================
# Le noeud ne mine jamais à la place d'un client : il fournit un modèle de bloc,
# le mineur cherche le nonce chez lui, puis soumet le bloc complet.
# Aucune inscription, aucun secret : n'importe qui peut miner.

_SUPPLY_CACHE = {"height": -2, "supply": 0}


def _cached_supply(db, tip_height: int) -> int:
    """Supply réelle, recalculée une seule fois par hauteur de chaîne."""
    if _SUPPLY_CACHE["height"] != tip_height:
        _SUPPLY_CACHE["supply"] = real_supply(db)
        _SUPPLY_CACHE["height"] = tip_height
    return _SUPPLY_CACHE["supply"]


def _is_valid_pub(pub: str) -> bool:
    """Une adresse CMIA est une clé publique secp256k1 (128 caractères hexadécimaux)."""
    try:
        if not isinstance(pub, str) or len(pub) != 128:
            return False
        VerifyingKey.from_string(bytes.fromhex(pub), curve=SECP256k1)
        return True
    except Exception:
        return False


def _record_miner(block: dict) -> None:
    """Met à jour les statistiques publiques des mineurs (sans jamais bloquer l'acceptation du bloc)."""
    try:
        coinbase = block["transactions"][0]
        pub = coinbase.get("recipient_pub")
        if not pub:
            return
        try:
            mark_block_mined(pub, int(coinbase.get("amount", 0)))
        except TypeError:
            mark_block_mined(pub)
    except Exception:
        pass


def _accept_block(db: Session, block: dict, outdated_is_ok: bool) -> dict:
    """
    Point d'entrée unique pour tout nouveau bloc (mineur ou pair P2P) :
    validation consensus complète, insertion atomique, puis propagation.
    """
    if not isinstance(block, dict):
        raise HTTPException(status_code=400, detail="invalid block")

    try:
        height = int(block["height"])
        block_hash = str(block["hash"])
    except (KeyError, TypeError, ValueError):
        raise HTTPException(status_code=400, detail="invalid block fields")

    existing = db.query(BlockModel).filter(BlockModel.hash == block_hash).first()
    if existing:
        return {
            "success": True,
            "status": "already_known",
            "height": int(existing.height),
            "hash": str(existing.hash),
        }

    current = db.query(BlockModel).order_by(BlockModel.height.desc()).first()
    if current is None:
        raise HTTPException(status_code=503, detail="blockchain not initialized")

    expected_height = int(current.height) + 1

    if height < expected_height:
        if outdated_is_ok:
            return {"success": True, "status": "outdated", "height": height}
        raise HTTPException(status_code=409, detail="block already outdated")

    if height > expected_height:
        raise HTTPException(
            status_code=409,
            detail={
                "error": "future_block",
                "expected_height": expected_height,
                "received_height": height,
            },
        )

    try:
        valid = validate_block_full(db, block)
    except Exception as exc:
        db.rollback()
        print(f"❌ validate_block_full exception: {type(exc).__name__}: {exc}", flush=True)
        raise HTTPException(status_code=400, detail="block validation failed")

    if not valid:
        raise HTTPException(status_code=400, detail="invalid block")

    # Anti-course : la chaîne a-t-elle avancé pendant la validation ?
    tip_now = db.query(BlockModel).order_by(BlockModel.height.desc()).first()
    if tip_now is None or int(tip_now.height) != height - 1:
        raise HTTPException(status_code=409, detail="chain advanced during validation")

    try:
        db.add(
            BlockModel(
                height=height,
                hash=block_hash,
                prev_hash=str(block["prev_hash"]),
                nonce=int(block["nonce"]),
                timestamp=int(block["timestamp"]),
                difficulty=int(block["difficulty"]),
                transactions=block["transactions"],
            )
        )
        db.flush()
        apply_block_utxos(db, block["transactions"], block_hash)
        db.commit()
    except Exception as exc:
        db.rollback()
        if db.query(BlockModel).filter(BlockModel.height == height).first():
            raise HTTPException(status_code=409, detail="block height already accepted") from exc
        print(f"❌ block insertion failed: {type(exc).__name__}: {exc}", flush=True)
        raise HTTPException(status_code=500, detail="failed to commit block") from exc

    _record_miner(block)
    SEEN_BLOCKS.add(block_hash)

    try:
        p2p_broadcast_block(block)
    except Exception:
        pass

    return {
        "success": True,
        "status": "accepted",
        "height": height,
        "hash": block_hash,
        "difficulty": int(block["difficulty"]),
    }


@app.post("/block/receive")
async def receive_block(block: dict, db: Session = Depends(get_db)):
    """Bloc reçu d'un pair P2P ou d'un nœud qui se synchronise."""
    return _accept_block(db, block, outdated_is_ok=True)


@app.get("/mining/tip")
def api_mining_tip(db: Session = Depends(get_db)):
    """Pointe de chaîne, très léger : les mineurs l'interrogent pour abandonner un travail périmé."""
    last = db.query(BlockModel).order_by(BlockModel.height.desc()).first()
    if last is None:
        raise HTTPException(status_code=503, detail="blockchain not initialized")
    return {
        "network_id": NETWORK_ID,
        "height": int(last.height),
        "hash": str(last.hash),
    }


@app.get("/mining/template")
def api_mining_template(miner_pub: str, db: Session = Depends(get_db)):
    """
    Modèle de bloc public. Aucun secret mineur : il faut seulement une adresse
    (clé publique secp256k1) qui recevra la récompense.
    """
    miner_pub = (miner_pub or "").strip()
    if not _is_valid_pub(miner_pub):
        raise HTTPException(
            status_code=400,
            detail="invalid miner_pub (clé publique secp256k1 de 128 caractères hexadécimaux attendue)",
        )

    last_block = db.query(BlockModel).order_by(BlockModel.height.desc()).first()
    if last_block is None:
        raise HTTPException(status_code=503, detail="blockchain not initialized")

    height = int(last_block.height) + 1
    prev_hash = str(last_block.hash)
    difficulty = calculate_next_difficulty(db, height)
    reward = recalc_reward_for_height(height)

    try:
        max_supply = int(os.getenv("MAX_SUPPLY", "10000000"))
    except ValueError:
        max_supply = 10_000_000

    if _cached_supply(db, int(last_block.height)) + reward > max_supply:
        raise HTTPException(status_code=410, detail="maximum supply reached")

    timestamp = int(time.time())

    coinbase = {
        "tx_hash": coinbase_tx_hash(miner_pub, reward, timestamp, height),
        "sender_pub": "NETWORK",
        "recipient_pub": miner_pub,
        "amount": reward,
        "signature": "",
        "created_at": timestamp,
        "type": "coinbase",
        "network_id": NETWORK_ID,
        "tx_version": TX_VERSION,
    }

    transactions = [coinbase]

    pending = (
        db.query(TransactionModel)
        .filter(TransactionModel.status == "pending")
        .order_by(TransactionModel.created_at.asc())
        .limit(MAX_MEMPOOL_TX)
        .all()
    )

    spent_in_template = set()

    for tx in pending:
        if len(transactions) >= MAX_BLOCK_TX:
            break

        inputs = [
            {
                "prev_tx_hash": i.prev_tx_hash,
                "output_index": int(i.output_index),
                "signature": i.signature,
            }
            for i in get_tx_inputs(db, tx.tx_hash)
        ]
        outputs = [
            {"recipient_pub": o.recipient_pub, "amount": int(o.amount)}
            for o in get_tx_outputs(db, tx.tx_hash)
        ]

        refs = {(i["prev_tx_hash"], i["output_index"]) for i in inputs}
        if not refs or refs & spent_in_template:
            continue

        candidate_tx = {
            "tx_hash": tx.tx_hash,
            "sender_pub": tx.sender_pub,
            "recipient_pub": tx.recipient_pub,
            "amount": int(tx.amount),
            "signature": tx.signature,
            "created_at": int(tx.created_at),
            "inputs": inputs,
            "outputs": outputs,
            "network_id": NETWORK_ID,
            "tx_version": TX_VERSION,
        }

        # On n'embarque que des transactions que le consensus acceptera :
        # une seule transaction douteuse ne doit jamais invalider tout le bloc.
        try:
            if not validate_block_transactions(
                db, {"transactions": [{"sender_pub": "NETWORK"}, candidate_tx]}
            ):
                continue
        except Exception:
            continue

        spent_in_template |= refs
        transactions.append(candidate_tx)

    # Seulement les champs que la base conserve : le hash du bloc les couvre tous.
    block_template = {
        "height": height,
        "prev_hash": prev_hash,
        "timestamp": timestamp,
        "difficulty": difficulty,
        "transactions": transactions,
        "nonce": 0,
    }

    return {
        "success": True,
        "network_id": NETWORK_ID,
        "height": height,
        "prev_hash": prev_hash,
        "difficulty": difficulty,
        "target": hex(difficulty_to_target(difficulty)),
        "reward": reward,
        "timestamp": timestamp,
        "miner_pub": miner_pub,
        "template": block_template,
    }


@app.post("/mining/submit")
async def api_mining_submit(block: dict, db: Session = Depends(get_db)):
    """Soumission d'un bloc dont le Proof of Work a été calculé par le mineur."""
    return _accept_block(db, block, outdated_is_ok=False)


@app.get("/utxos/{public_key}")
def api_utxos(public_key: str, db: Session = Depends(get_db)):
    """UTXO non dépensés d'une adresse (lecture publique), utile aux portefeuilles externes."""
    rows = (
        db.query(UTXOModel)
        .filter(UTXOModel.recipient_pub == public_key, UTXOModel.spent == False)  # noqa: E712
        .order_by(UTXOModel.id.asc())
        .limit(500)
        .all()
    )
    return {
        "public_key": public_key,
        "count": len(rows),
        "utxos": [
            {"tx_hash": u.tx_hash, "output_index": int(u.output_index), "amount": int(u.amount)}
            for u in rows
        ],
    }
