import asyncio
import json
import requests

# Ces variables seront écrasées par les variables d'environnement au lancement
P2P_HOST = "0.0.0.0"
P2P_PORT = 9000
P2P_PEERS = []
NODE_PORT = 8000

# Référence à la boucle asyncio principale, capturée au démarrage du serveur P2P.
# Indispensable pour planifier les broadcasts depuis un thread FastAPI (routes sync).
MAIN_LOOP = None


async def p2p_handle_client(reader, writer):
    """Gère les messages entrants envoyés par d'autres nœuds de la communauté."""
    try:
        while True:
            raw = await reader.readline()
            if not raw:
                break

            msg = json.loads(raw.decode())
            msg_type = msg.get("type")
            data = msg.get("data")

            if msg_type == "ping":
                writer.write((json.dumps({"type": "pong"}) + "\n").encode())
                await writer.drain()

            elif msg_type == "new_tx":
                # Redirection vers l'API locale, sans bloquer la boucle asyncio.
                await _post_local("/transaction/receive", data)

            elif msg_type == "new_block":
                # Redirection vers l'API locale, sans bloquer la boucle asyncio.
                await _post_local("/block/receive", data)

            elif msg_type == "sync_request":
                # Un autre nœud demande l'historique de notre chaîne
                chain = await _get_local("/chain")
                if chain is not None:
                    writer.write((json.dumps({"type": "chain", "data": chain}) + "\n").encode())
                    await writer.drain()

    except Exception:
        pass
    finally:
        writer.close()
        await writer.wait_closed()


async def _post_local(path: str, data):
    """POST vers notre propre API sans bloquer la boucle (requests tourne dans un thread)."""
    def _do():
        try:
            requests.post(f"http://127.0.0.1:{NODE_PORT}{path}", json=data, timeout=2)
        except Exception:
            pass
    await asyncio.to_thread(_do)


async def _get_local(path: str):
    """GET vers notre propre API sans bloquer la boucle. Renvoie le JSON ou None."""
    def _do():
        try:
            res = requests.get(f"http://127.0.0.1:{NODE_PORT}{path}", timeout=2)
            if res.status_code == 200:
                return res.json()
        except Exception:
            pass
        return None
    return await asyncio.to_thread(_do)


async def p2p_start_server(host: str, port: int, node_port: int, p2p_peers: list):
    """Démarre le serveur d'écoute P2P."""
    global P2P_HOST, P2P_PORT, NODE_PORT, P2P_PEERS, MAIN_LOOP
    P2P_HOST = host
    P2P_PORT = port
    NODE_PORT = node_port
    P2P_PEERS = p2p_peers
    # On mémorise la boucle qui fait tourner le serveur P2P : c'est elle qui
    # exécutera les broadcasts, même quand ils sont déclenchés depuis un thread.
    MAIN_LOOP = asyncio.get_running_loop()

    server = await asyncio.start_server(p2p_handle_client, P2P_HOST, P2P_PORT)
    print(f"🌐 Serveur P2P CMIA actif sur {P2P_HOST}:{P2P_PORT}")
    async with server:
        await server.serve_forever()


async def p2p_send_message(host: str, port: int, message: dict):
    """Envoie un message unique à un pair spécifique."""
    try:
        reader, writer = await asyncio.open_connection(host, port)
        writer.write((json.dumps(message) + "\n").encode())
        await writer.drain()
        writer.close()
        await writer.wait_closed()
    except Exception:
        pass


def parse_p2p_peer(peer: str):
    """Découpe une chaîne 'IP:PORT'."""
    host, port = peer.split(":")
    return host, int(port)


def _schedule(coro):
    """
    Planifie une coroutine sur la boucle principale, que l'appelant soit
    dans la boucle (route async) ou dans un thread du threadpool (route sync).
    C'est ce qui règle le bug 'coroutine was never awaited'.
    """
    if MAIN_LOOP is None:
        # Serveur P2P pas encore démarré : on ferme proprement la coroutine
        # pour éviter le RuntimeWarning au lieu de la laisser en orphelin.
        coro.close()
        return

    try:
        running = asyncio.get_running_loop()
    except RuntimeError:
        running = None

    if running is MAIN_LOOP:
        # On est déjà dans la boucle principale : create_task suffit.
        MAIN_LOOP.create_task(coro)
    else:
        # On est dans un autre thread (routes FastAPI sync) : planification thread-safe.
        asyncio.run_coroutine_threadsafe(coro, MAIN_LOOP)


async def _broadcast(msg_type: str, payload: dict):
    """Diffuse un message à tous les pairs en parallèle."""
    tasks = []
    for peer in P2P_PEERS:
        try:
            host, port = parse_p2p_peer(peer)
            tasks.append(p2p_send_message(host, port, {"type": msg_type, "data": payload}))
        except Exception:
            pass
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)


def p2p_broadcast_tx(tx_dict: dict):
    """Diffuse une transaction à tout le réseau P2P."""
    _schedule(_broadcast("new_tx", tx_dict))


def p2p_broadcast_block(block_dict: dict):
    """Diffuse un bloc à tout le réseau P2P."""
    _schedule(_broadcast("new_block", block_dict))
