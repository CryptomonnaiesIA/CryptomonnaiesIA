"""
Synchronisation des blocs : un noeud qui démarre (ou qui a raté des blocs) récupère
les blocs manquants auprès de noeuds publics, par lots de 100, et les fait valider
par sa propre API locale (/block/receive) : aucune confiance accordée au pair.

Variable d'environnement :
    SYNC_PEERS   adresses HTTP des noeuds à suivre, séparées par des virgules
                 ex. SYNC_PEERS=https://api.cryptomonnaiesia.com

Limite V1 : pas de réorganisation. Si le pair est sur une autre branche, la
synchronisation s'arrête et le signale.
"""
import os
import time

import requests

BATCH = 100
INTERVAL = int(os.getenv("SYNC_INTERVAL", "30"))
_GENESIS_OK = {}  # peer -> True/False une fois la comparaison de genesis faite


def _info(base: str) -> dict:
    r = requests.get(f"{base}/info", timeout=15)
    r.raise_for_status()
    return r.json()


def _genesis_hash(base: str):
    r = requests.get(f"{base}/chain", params={"from_height": 0, "limit": 1}, timeout=15)
    r.raise_for_status()
    blocks = r.json().get("blocks", [])
    return blocks[0]["hash"] if blocks else None


def sync_from_peer(local: str, peer: str) -> None:
    peer = peer.rstrip("/")
    mine = _info(local)
    theirs = _info(peer)

    if theirs.get("network_id") != mine.get("network_id"):
        print(f"⚠️ SYNC {peer}: autre réseau ({theirs.get('network_id')}), ignoré", flush=True)
        return

    if peer not in _GENESIS_OK:
        same = _genesis_hash(peer) == _genesis_hash(local)
        _GENESIS_OK[peer] = same
        if not same:
            print(f"⚠️ SYNC {peer}: genesis différent, ce noeud n'est pas sur la même chaîne", flush=True)
    if not _GENESIS_OK[peer]:
        return

    height = int(mine["height"])
    target = int(theirs["height"])
    if target <= height:
        return

    print(f"🔄 SYNC {peer}: {height} -> {target}", flush=True)
    next_height = height + 1

    while next_height <= target:
        r = requests.get(
            f"{peer}/chain",
            params={"from_height": next_height, "limit": BATCH},
            timeout=60,
        )
        r.raise_for_status()
        blocks = r.json().get("blocks", [])
        if not blocks:
            break

        for block in blocks:
            resp = requests.post(f"{local}/block/receive", json=block, timeout=120)
            if resp.status_code != 200:
                print(
                    f"⚠️ SYNC arrêtée au bloc {block.get('height')}: "
                    f"{resp.status_code} {resp.text[:160]} "
                    "(branche différente ou bloc incompatible avec les règles actuelles)",
                    flush=True,
                )
                return
            next_height = int(block["height"]) + 1

    print(f"✅ SYNC terminée à la hauteur {next_height - 1}", flush=True)


def sync_loop(node_port: int, peers: list) -> None:
    local = f"http://127.0.0.1:{node_port}"

    # Attendre que l'API locale réponde
    while True:
        try:
            _info(local)
            break
        except Exception:
            time.sleep(1)

    while True:
        for peer in peers:
            try:
                sync_from_peer(local, peer)
            except Exception as exc:
                print(f"⚠️ SYNC {peer}: {type(exc).__name__}: {exc}", flush=True)
        time.sleep(INTERVAL)
