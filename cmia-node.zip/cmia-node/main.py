import os
import asyncio
import threading

from dotenv import load_dotenv

# Le .env doit être chargé AVANT l'import de l'API, qui lit ses variables à l'import.
load_dotenv()

# Dossier de la base SQLite par défaut (data/blockchain_<port>.db)
os.makedirs("data", exist_ok=True)

import uvicorn

from network.api import app, create_genesis_block, get_or_create_network_state, recompute_network_state
from network.p2p import p2p_start_server
from network.sync import sync_loop
from db import SessionLocal, init_db

NODE_PORT = int(os.getenv("NODE_PORT", "8000"))
P2P_HOST = os.getenv("P2P_HOST", "0.0.0.0")
P2P_PORT = int(os.getenv("P2P_PORT", "9000"))

# Pairs P2P (diffusion TCP) : ip:port séparés par des virgules
P2P_PEERS = [p.strip() for p in os.getenv("P2P_PEERS", "").split(",") if p.strip()]

# Noeuds à suivre pour la synchronisation : URLs HTTP séparées par des virgules
SYNC_PEERS = [p.strip() for p in os.getenv("SYNC_PEERS", "").split(",") if p.strip()]


def start_p2p_thread():
    """Lance le serveur P2P dans une boucle d'événements asynchrone dédiée."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(p2p_start_server(P2P_HOST, P2P_PORT, NODE_PORT, P2P_PEERS))


if __name__ == "__main__":
    print("⚙️ Initialisation du réseau et de la blockchain CMIA...")

    try:
        init_db()
        print("📁 Tables créées ou vérifiées.")
    except Exception as e:
        print(f"⚠️ Note sur la création des tables : {e}")

    db = SessionLocal()
    try:
        create_genesis_block(db)
        get_or_create_network_state(db)
        recompute_network_state(db)
        print("✅ Base de données locale et état du réseau synchronisés.")
    except Exception as e:
        print(f"❌ Erreur lors de l'initialisation : {e}")
    finally:
        db.close()

    print("🌐 Lancement du protocole Peer-to-Peer...")
    threading.Thread(target=start_p2p_thread, daemon=True).start()

    if SYNC_PEERS:
        print(f"🔄 Synchronisation activée : {', '.join(SYNC_PEERS)}")
        threading.Thread(target=sync_loop, args=(NODE_PORT, SYNC_PEERS), daemon=True).start()

    print(f"🚀 Lancement de l'API Node sur http://localhost:{NODE_PORT}")
    uvicorn.run(app, host="0.0.0.0", port=NODE_PORT)
