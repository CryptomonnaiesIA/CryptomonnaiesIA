# CMIA Node

Nœud de la blockchain **CMIA** (CryptomonnaiesIA) : Proof of Work SHA-256, modèle UTXO, signatures secp256k1, API REST (FastAPI) et réseau pair-à-pair.

Site : https://cryptomonnaiesia.com · Mineur : dépôt `cmia-miner`

> **Statut : expérimental.** Le minage est **ouvert** : n'importe qui peut miner, sans inscription ni autorisation. Le Proof of Work est calculé par le mineur, le nœud ne fait que le vérifier. Voir [Limites actuelles](#limites-actuelles).

---

## Comment fonctionne le minage ouvert

1. Le mineur demande un modèle de bloc : `GET /mining/template?miner_pub=<adresse>`.
2. Il cherche un `nonce` sur sa propre machine jusqu'à obtenir un hash inférieur à la cible.
3. Il envoie le bloc complet : `POST /mining/submit`.
4. Le nœud vérifie **toutes** les règles de consensus (ci-dessous). Si le bloc est valide, il est enregistré et diffusé aux pairs.

Aucun identifiant, aucun secret : seule une adresse (clé publique secp256k1) est nécessaire pour recevoir la récompense.

### Règles de consensus

Appliquées par chaque nœud à chaque bloc (`core/blockchain.py`, fonction `validate_block_full`) :

| Règle | Détail |
|---|---|
| Champs du bloc | Exactement `height`, `prev_hash`, `timestamp`, `difficulty`, `transactions`, `nonce`, `hash` |
| Hash | SHA-256 du JSON du bloc (clés triées, séparateurs `,` et `:`), sans le champ `hash` |
| Proof of Work | `hash < 2^(256 - difficulty)` |
| Chaînage | `height` = hauteur de la pointe + 1, `prev_hash` = hash de la pointe |
| Difficulté | Imposée par le réseau : ajustée tous les 5 blocs pour viser 30 secondes par bloc (minimum 3, maximum 240) |
| Horodatage | Au plus 60 s dans le futur, au plus 60 s avant le bloc précédent |
| Coinbase | Première transaction et seule de son type, montant = récompense du bloc, `tx_hash` recalculé |
| Récompense | 25 CMIA au départ, divisée par deux tous les 5 000 blocs (minimum 1) |
| Supply | Jamais au-dessus de 10 000 000 CMIA |
| Transactions | 200 maximum par bloc, 2 Mo maximum, `tx_hash` recalculé, signatures et UTXO vérifiés, pas de double dépense |

Ces valeurs sont dans `core/blockchain.py`. Les modifier crée une chaîne incompatible avec le réseau principal.

---

## Installation

Prérequis : Python 3.10 ou plus (testé avec 3.12).

```bash
git clone https://github.com/julienfiquet/cmia-node.git
cd cmia-node
python -m venv venv
```

Activer l'environnement :

```bash
# Windows (PowerShell)
venv\Scripts\Activate.ps1
# Linux / macOS
source venv/bin/activate
```

Puis :

```bash
pip install -r requirements.txt
cp .env.example .env        # Windows : copy .env.example .env
python main.py
```

Windows : `start-node.bat` fait tout cela. Linux / macOS : `./start-node.sh`.

`main.py` crée la base SQLite (dossier `data/`) et le bloc Genesis, démarre le serveur P2P et la synchronisation en tâche de fond, puis lance l'API sur `NODE_PORT`. Vérification :

```bash
curl http://localhost:8000/        # {"status":"CMIA Node Online", ...}
curl http://localhost:8000/info
```

> `/docs` est volontairement désactivé. Pour PostgreSQL : `pip install psycopg2-binary` et renseignez `DATABASE_URL`.

---

## Rejoindre le réseau

Un nœud qui démarre crée un bloc Genesis local. Pour suivre une chaîne existante, indiquez un nœud à suivre dans `.env` :

```bash
SYNC_PEERS=https://api.cryptomonnaiesia.com
```

Le nœud télécharge alors les blocs manquants par lots de 100 et **vérifie chacun avec ses propres règles** : aucune confiance n'est accordée au pair. La synchronisation est refusée si le Genesis du pair est différent. Pour comparer votre Genesis avec celui d'un nœud :

```bash
python check_genesis.py https://api.cryptomonnaiesia.com
```

Pour diffuser vos blocs et transactions en direct à d'autres nœuds, renseignez `P2P_PEERS` (`ip:port`, port 9000 par défaut, à ouvrir sur votre routeur).

---

## Configuration

Variables du fichier `.env` (toutes facultatives) :

| Variable | Défaut | Rôle |
|---|---|---|
| `NODE_PORT` | `8000` | Port de l'API |
| `DATABASE_URL` | `sqlite:///./data/blockchain_<port>.db` | Base de données |
| `P2P_HOST` / `P2P_PORT` | `0.0.0.0` / `9000` | Écoute du serveur P2P |
| `P2P_PEERS` | vide | Pairs à qui diffuser, `ip:port` séparés par des virgules |
| `SYNC_PEERS` | vide | Nœuds à suivre (URLs HTTP) |
| `SYNC_INTERVAL` | `30` | Secondes entre deux synchronisations |
| `ADMIN_API_SECRET` | vide | Accès aux routes d'administration. Vide = fermées |
| `RATE_MAX` / `RATE_WINDOW` | `120` / `60` | Requêtes autorisées par IP et par fenêtre (secondes) |
| `MAX_MEMPOOL_TX` | `5000` | Taille maximale de la mempool |
| `MAX_TX_PER_SENDER_IN_MEMPOOL` | `50` | Transactions en attente par expéditeur |
| `MAX_TX_BYTES` | `25000` | Taille maximale d'une transaction |
| `TREASURY_API_SECRET` / `TREASURY_WALLET_PUB` | vide | Accès à `/treasury/send` |
| `USE_VAULT` / `VAULT_ADDR` / `VAULT_TOKEN` / `VAULT_KEY_NAME` | `false` / `http://127.0.0.1:8200` / vide / `wallet-key` | Chiffrement des clés des wallets du nœud (Vault) |
| `NETWORK_ID` | `cmia-mainnet-v1` | Identité du réseau (en changer crée une autre chaîne) |

Un mineur interroge `/mining/tip` toutes les 3 secondes : la limite par défaut (120 requêtes par minute et par IP) suffit pour un mineur par adresse IP.

---

## API

Lecture publique :

| Route | Contenu |
|---|---|
| `GET /` | État du nœud |
| `GET /info` | Réseau, difficulté, hauteur, récompense, supply, mineurs actifs |
| `GET /state` | Supply, récompense, hauteur |
| `GET /chain?from_height=N&limit=100` | Blocs par lots de 100 maximum |
| `GET /mempool` | Transactions en attente |
| `GET /miners` | Statistiques et classement des mineurs |
| `GET /balance/{adresse}` | Solde d'une adresse |
| `GET /utxos/{adresse}` | Sorties non dépensées d'une adresse |

Minage et réseau :

| Route | Rôle |
|---|---|
| `GET /mining/tip` | Pointe de la chaîne (léger, pour détecter un travail périmé) |
| `GET /mining/template?miner_pub=...` | Modèle de bloc à miner |
| `POST /mining/submit` | Soumission d'un bloc miné |
| `POST /block/receive` | Bloc envoyé par un pair ou par la synchronisation |
| `POST /transaction/receive` | Transaction signée par son propriétaire |

Administration, protégée par l'en-tête `X-Admin-Key` : `POST /wallet/create`, `GET /wallets`, `POST /transaction/send-strict` (`ADMIN_API_SECRET`), `POST /treasury/send` (`TREASURY_API_SECRET`). Fermées tant que le secret correspondant est vide.

Envoyer des CMIA depuis sa propre clé : voir `cmia_wallet.py` dans le dépôt du mineur. La transaction est signée localement, la clé privée ne quitte jamais votre machine.

---

## Sécurité

- Ne commitez jamais `.env`, `data/`, ni de fichier `.db` ou `wallet*.json`.
- Les wallets gérés par le nœud (routes d'administration) stockent leurs clés privées **en clair** tant que Vault n'est pas activé (`USE_VAULT=true`). Sur un nœud public, laissez `ADMIN_API_SECRET` vide ou activez Vault. Les mineurs et utilisateurs gardent leurs propres clés et n'en ont pas besoin.
- Le limiteur de débit lit l'IP dans `cf-connecting-ip` ou `x-forwarded-for` : placez le nœud derrière un proxy ou un tunnel de confiance (Cloudflare par exemple), sinon ces en-têtes peuvent être falsifiés.
- Le port P2P n'est pas authentifié : les blocs et transactions reçus sont entièrement validés avant acceptation, mais n'ouvrez ce port que si vous voulez recevoir des pairs.

---

## Limites actuelles

- **Pas de réorganisation de chaîne.** Si deux mineurs trouvent un bloc à la même hauteur sur deux nœuds différents, ces nœuds peuvent rester sur des branches différentes et la synchronisation s'arrête avec un message. Le choix de la chaîne au plus grand travail cumulé est prévu pour la version suivante.
- **Difficulté** : l'ajustement tous les 5 blocs est très réactif mais sensible aux horodatages. Une fenêtre plus longue est recommandée avant un déploiement à grande échelle.
- Le serveur P2P n'a pas d'authentification ni de protection contre les envois massifs.
- Les frais de transaction ne sont pas reversés aux mineurs.

---

## Structure

```
main.py              Lancement : base, Genesis, P2P, synchronisation, API
db.py                Modèles SQLAlchemy
vault_client.py      Chiffrement des clés (Vault, optionnel)
miners_registry.py   Statistiques publiques des mineurs
check_genesis.py     Compare votre Genesis avec celui d'un nœud
core/blockchain.py   Règles de consensus, validation, difficulté
network/api.py       API HTTP et minage public
network/p2p.py       Diffusion TCP vers les pairs
network/sync.py      Synchronisation par lots depuis un nœud
```

## Licence

MIT, voir le fichier `LICENSE`.
