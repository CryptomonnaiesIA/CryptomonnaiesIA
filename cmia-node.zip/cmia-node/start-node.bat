@echo off
cd /d "%~dp0"
cls

echo [1/4] Verification de Python...
where python >nul 2>&1
if errorlevel 1 goto nopython

echo [2/4] Configuration du fichier .env...
if not exist .env copy .env.example .env >nul

echo [3/4] Environnement virtuel et dependances...
if not exist venv python -m venv venv
call venv\Scripts\activate.bat
python -m pip install -r requirements.txt
if errorlevel 1 goto pipfail

echo [4/4] Demarrage du noeud CMIA...
python main.py
pause
exit /b 0

:nopython
echo [ERREUR] Python n'est pas installe.
pause
exit /b 1

:pipfail
echo [ERREUR] L'installation des dependances a echoue. Python 3.12 ou 3.13 est recommande.
pause
exit /b 1
