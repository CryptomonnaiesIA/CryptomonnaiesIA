# CMIA Open Miner

Mineur public pour la blockchain **CMIA**. Le Proof of Work est calculé **sur votre machine** ; aucune inscription, aucune autorisation, aucun secret à échanger : il suffit de lancer le programme.

Site : https://cryptomonnaiesia.com · Nœud : dépôt `cmia-node`

---

## Démarrage rapide

Prérequis : Python 3.10 ou plus.

```bash
git clone https://github.com/julienfiquet/cmia-miner.git
cd cmia-miner
pip install -r requirements.txt
python auto_miner.py
```

Windows : double-cliquez sur `start-miner.bat`. Linux / macOS : `./start-miner.sh`.

Au premier lancement, le mineur crée un portefeuille dans `wallet.json` (adresse et clé privée) et commence à miner sur le nœud officiel. Les récompenses arrivent à cette adresse.

> **Sauvegardez `wallet.json`.** Il contient la clé privée qui contrôle vos CMIA : sans lui, vos récompenses sont perdues. Ne le partagez jamais et ne le publiez jamais (il est déjà dans `.gitignore`).

---

## Comment ça marche

1. Le mineur demande un modèle de bloc au nœud (`GET /mining/template`), avec votre adresse comme destinataire de la récompense.
2. Il cherche un `nonce` sur tous vos cœurs jusqu'à obtenir un hash inférieur à la cible (SHA-256).
3. Il envoie le bloc (`POST /mining/submit`) ; le nœud le vérifie entièrement avant de l'accepter.
4. Pendant la recherche, il surveille la pointe de la chaîne (`GET /mining/tip`) : si un autre mineur trouve le bloc avant vous, il abandonne et repart sur le suivant.

La difficulté est fixée par le réseau et s'ajuste tous les 5 blocs pour viser 30 secondes par bloc. Le programme est en Python : ses performances sont modestes, ce qui convient tant que la difficulté reste basse.

---

## Options

```bash
python auto_miner.py --node http://localhost:8000      # autre nœud
python auto_miner.py --miner-pub <adresse>             # récompenses vers une adresse existante
python auto_miner.py --threads 4                       # nombre de processus
python auto_miner.py --blocks 10                       # s'arrête après 10 blocs acceptés
python auto_miner.py --wallet mon_wallet.json          # autre fichier portefeuille
```

Variables d'environnement équivalentes : `CMIA_NODE` (nœud) et `MINER_PUB` (adresse).

---

## Envoyer des CMIA

`cmia_wallet.py` utilise le même `wallet.json`. La transaction est signée sur votre machine ; la clé privée n'est jamais envoyée.

```bash
python cmia_wallet.py address
python cmia_wallet.py balance
python cmia_wallet.py send --to <adresse> --amount 5
```

La transaction est confirmée quand un mineur trouve le bloc suivant.

---

## Messages courants

| Message | Signification |
|---|---|
| `Bloc dépassé : un autre mineur a été plus rapide` | Normal : quelqu'un a trouvé le bloc avant vous |
| `Travail périmé` | Un nouveau bloc est arrivé, le mineur repart sur le suivant |
| `Adresse refusée par le noeud` | L'adresse doit être une clé publique secp256k1 de 128 caractères hexadécimaux |
| `Trop de requêtes` (429) | Limite du nœud atteinte, le mineur patiente 10 secondes |
| `Supply maximale atteinte` | Il n'y a plus de CMIA à miner |
| `[RÉSEAU] ...` | Nœud injoignable : le mineur réessaie toutes les 5 secondes |

---

## Déploiement en worker (Render ou similaire)

Le `Procfile` lance `python auto_miner.py`. Générez votre adresse **en local**, puis renseignez seulement l'adresse publique dans les variables d'environnement du service :

```
MINER_PUB=<votre adresse publique>
CMIA_NODE=https://api.cryptomonnaiesia.com
```

Ne placez jamais votre clé privée sur un serveur.

---

## Licence

MIT, voir le fichier `LICENSE`.
