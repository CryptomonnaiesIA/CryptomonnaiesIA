#!/usr/bin/env python3
"""
CMIA Open Miner : minage public et sans inscription.

Le Proof of Work est calculé sur VOTRE machine. Le noeud fournit un modèle de bloc,
vous cherchez le nonce, puis vous soumettez le bloc que le noeud vérifie.

    python auto_miner.py                      # crée ou réutilise wallet.json
    python auto_miner.py --node http://localhost:8000
    python auto_miner.py --miner-pub <adresse>
"""
import argparse
import hashlib
import json
import multiprocessing
import os
import queue as queue_module
import sys
import time

import requests

DEFAULT_NODE = os.getenv("CMIA_NODE", "https://api.cryptomonnaiesia.com")
WALLET_FILE = "wallet.json"
TIP_POLL_SECONDS = 3        # vérifie si un autre mineur a trouvé le bloc
MAX_TEMPLATE_AGE = 120      # renouvelle le modèle (nouvelles transactions, horodatage)
BLOCK_KEYS = ("height", "prev_hash", "timestamp", "difficulty", "transactions", "nonce")


# ---------------------------------------------------------------- portefeuille
def load_or_create_wallet(path: str) -> dict:
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            return json.load(f)

    from ecdsa import SECP256k1, SigningKey

    sk = SigningKey.generate(curve=SECP256k1)
    wallet = {
        "public_key": sk.verifying_key.to_string().hex(),
        "private_key": sk.to_string().hex(),
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(wallet, f, indent=2)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass

    print("=" * 60)
    print(f"Nouveau portefeuille créé : {path}")
    print("SAUVEGARDEZ ce fichier : il contient la clé privée qui contrôle vos CMIA.")
    print("Ne le partagez jamais et ne le publiez jamais.")
    print("=" * 60)
    return wallet


# ------------------------------------------------------------------- Proof of Work
def block_hash(block: dict) -> str:
    data = {k: v for k, v in block.items() if k != "hash"}
    raw = json.dumps(data, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()


def split_for_nonce(block: dict):
    """
    Le noeud hache le JSON trié du bloc. On pré-calcule le texte avant et après le nonce
    pour ne reconstruire que le nonce à chaque essai (beaucoup plus rapide).
    """
    marker = "\0NONCE\0"
    probe = dict(block)
    probe["nonce"] = marker
    text = json.dumps(
        {k: v for k, v in probe.items() if k != "hash"},
        sort_keys=True,
        separators=(",", ":"),
    )
    before, after = text.split(json.dumps(marker))
    return before.encode(), after.encode()


def worker(prefix, suffix, target, start, step, stop_event, result_queue, counter):
    base = hashlib.sha256(prefix)
    nonce = start
    tries = 0
    while True:
        h = base.copy()
        h.update(str(nonce).encode())
        h.update(suffix)
        digest = h.digest()
        if int.from_bytes(digest, "big") < target:
            result_queue.put((nonce, digest.hex()))
            return
        nonce += step
        tries += 1
        if tries == 20000:
            with counter.get_lock():
                counter.value += tries
            tries = 0
            if stop_event.is_set():
                return


def mine_block(block: dict, difficulty: int, processes: int, abort_check):
    """Cherche un nonce. Retourne le bloc complet, ou None si abort_check() devient vrai."""
    ctx = multiprocessing.get_context("spawn")
    result_queue = ctx.Queue()
    stop_event = ctx.Event()
    counter = ctx.Value("Q", 0)

    prefix, suffix = split_for_nonce(block)
    target = 2 ** (256 - int(difficulty))

    jobs = [
        ctx.Process(
            target=worker,
            args=(prefix, suffix, target, i, processes, stop_event, result_queue, counter),
            daemon=True,
        )
        for i in range(processes)
    ]
    for p in jobs:
        p.start()

    started = time.time()
    found = None
    try:
        while found is None:
            try:
                nonce, digest = result_queue.get(timeout=1)
                found = dict(block)
                found["nonce"] = nonce
                found["hash"] = digest
            except queue_module.Empty:
                if abort_check():
                    break
    finally:
        stop_event.set()
        for p in jobs:
            if p.is_alive():
                p.terminate()
        for p in jobs:
            p.join()

    elapsed = max(time.time() - started, 0.001)
    return found, counter.value / elapsed


# ------------------------------------------------------------------------ réseau
class Node:
    def __init__(self, url: str):
        self.url = url.rstrip("/")
        self.http = requests.Session()

    def template(self, miner_pub: str) -> dict:
        r = self.http.get(f"{self.url}/mining/template", params={"miner_pub": miner_pub}, timeout=15)
        if r.status_code == 410:
            raise SystemExit("Supply maximale atteinte : il n'y a plus de CMIA à miner.")
        if r.status_code == 400:
            raise SystemExit(f"Adresse refusée par le noeud : {r.text}")
        r.raise_for_status()
        return r.json()

    def tip(self) -> dict:
        r = self.http.get(f"{self.url}/mining/tip", timeout=10)
        r.raise_for_status()
        return r.json()

    def submit(self, block: dict) -> requests.Response:
        return self.http.post(f"{self.url}/mining/submit", json=block, timeout=30)


def main():
    parser = argparse.ArgumentParser(description="CMIA Open Miner")
    parser.add_argument("--node", default=DEFAULT_NODE, help="URL du noeud CMIA")
    parser.add_argument("--miner-pub", default=os.getenv("MINER_PUB"), help="Adresse qui reçoit les récompenses")
    parser.add_argument("--wallet", default=WALLET_FILE, help="Fichier portefeuille (créé s'il n'existe pas)")
    parser.add_argument("--threads", type=int, default=os.cpu_count() or 1, help="Nombre de processus")
    parser.add_argument("--blocks", type=int, default=0, help="S'arrêter après N blocs acceptés (0 = sans limite)")
    args = parser.parse_args()

    miner_pub = args.miner_pub or load_or_create_wallet(args.wallet)["public_key"]
    processes = max(1, args.threads)
    node = Node(args.node)

    print("=" * 48)
    print("                CMIA OPEN MINER")
    print("=" * 48)
    print(f"Noeud    : {node.url}")
    print(f"Adresse  : {miner_pub}")
    print(f"Processus: {processes}")
    print("=" * 48)

    accepted = 0
    earned = 0

    while True:
        try:
            tpl = node.template(miner_pub)
            template_block = tpl["template"]
            block = {k: template_block[k] for k in BLOCK_KEYS}
            difficulty = int(tpl["difficulty"])
            prev_hash = tpl["prev_hash"]
            began = time.time()
            last_poll = [began]

            print(f"[+] Bloc {tpl['height']} | difficulté {difficulty} bits | récompense {tpl['reward']} CMIA")

            def stale() -> bool:
                now = time.time()
                if now - began > MAX_TEMPLATE_AGE:
                    return True
                if now - last_poll[0] >= TIP_POLL_SECONDS:
                    last_poll[0] = now
                    try:
                        return node.tip()["hash"] != prev_hash
                    except requests.RequestException:
                        return False
                return False

            found, hashrate = mine_block(block, difficulty, processes, stale)

            if found is None:
                print("[~] Travail périmé (un autre bloc est arrivé) : nouveau modèle...")
                continue

            rate = f"  ({hashrate/1000:.0f} kH/s)" if hashrate > 0 else ""
            print(f"[+] Preuve de travail trouvée : {found['hash']}{rate}")

            resp = node.submit(found)
            if resp.status_code == 200:
                accepted += 1
                earned += int(tpl["reward"])
                print(f"[OK] Bloc {tpl['height']} accepté  | total : {accepted} blocs, {earned} CMIA")
                if args.blocks and accepted >= args.blocks:
                    print("Nombre de blocs demandé atteint, arrêt.")
                    return
            elif resp.status_code == 409:
                print("[~] Bloc dépassé : un autre mineur a été plus rapide.")
            elif resp.status_code == 429:
                print("[!] Trop de requêtes, pause de 10 s.")
                time.sleep(10)
            else:
                print(f"[ERREUR] Bloc refusé : {resp.status_code} {resp.text}")
                time.sleep(3)

        except requests.RequestException as exc:
            print(f"[RÉSEAU] {exc}")
            time.sleep(5)
        except KeyboardInterrupt:
            print("\nArrêt demandé.")
            return


if __name__ == "__main__":
    multiprocessing.freeze_support()
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
