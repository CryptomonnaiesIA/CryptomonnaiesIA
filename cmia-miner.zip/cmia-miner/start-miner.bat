@echo off
cd /d "%~dp0"
cls

echo [1/3] Verification de Python...
where python >nul 2>&1
if errorlevel 1 goto nopython

echo [2/3] Environnement virtuel et dependances...
if not exist venv python -m venv venv
call venv\Scripts\activate.bat
python -m pip install -r requirements.txt
if errorlevel 1 goto pipfail

echo [3/3] Demarrage du mineur CMIA...
python auto_miner.py %*
pause
exit /b 0

:nopython
echo [ERREUR] Python n'est pas installe.
pause
exit /b 1

:pipfail
echo [ERREUR] L'installation des dependances a echoue.
pause
exit /b 1
