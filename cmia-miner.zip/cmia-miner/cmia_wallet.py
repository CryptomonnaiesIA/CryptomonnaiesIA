#!/usr/bin/env python3
"""
Portefeuille CMIA en ligne de commande : vos clés restent chez vous.

    python cmia_wallet.py address
    python cmia_wallet.py balance
    python cmia_wallet.py send --to <adresse> --amount 5

Utilise le même fichier wallet.json que le mineur.
"""
import argparse
import hashlib
import json
import os
import sys
import time

import requests
from ecdsa import SECP256k1, SigningKey

DEFAULT_NODE = os.getenv("CMIA_NODE", "https://api.cryptomonnaiesia.com")
TX_VERSION = 1


def load_wallet(path):
    if not os.path.exists(path):
        sys.exit(f"Portefeuille introuvable : {path} (lancez d'abord le mineur pour le créer).")
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def intent_message(network_id, sender_pub, inputs, outputs, fee):
    return json.dumps(
        {
            "network_id": network_id,
            "tx_version": TX_VERSION,
            "sender_pub": sender_pub,
            "inputs": inputs,
            "outputs": outputs,
            "fee": fee,
        },
        sort_keys=True,
        separators=(",", ":"),
    )


def tx_hash_of(sender_pub, inputs, outputs, signature, created_at):
    raw = json.dumps(
        {
            "sender_pub": sender_pub,
            "inputs": inputs,
            "outputs": outputs,
            "signature": signature,
            "created_at": created_at,
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(raw.encode()).hexdigest()


def cmd_balance(args, wallet):
    r = requests.get(f"{args.node}/balance/{wallet['public_key']}", timeout=15)
    r.raise_for_status()
    data = r.json()
    print(f"Solde : {data['balance']} CMIA ({data['utxo_count']} sorties non dépensées)")


def cmd_send(args, wallet):
    pub = wallet["public_key"]
    node = args.node.rstrip("/")

    if args.amount <= 0:
        sys.exit("Le montant doit être positif.")
    if args.to == pub:
        sys.exit("Le destinataire est votre propre adresse.")

    info = requests.get(f"{node}/info", timeout=15).json()
    network_id = info["network_id"]

    utxos = requests.get(f"{node}/utxos/{pub}", timeout=15).json()["utxos"]
    selected, total = [], 0
    for u in utxos:
        selected.append(u)
        total += int(u["amount"])
        if total >= args.amount:
            break
    if total < args.amount:
        sys.exit(f"Solde insuffisant : {total} CMIA disponibles.")

    outputs = [{"recipient_pub": args.to, "amount": args.amount}]
    if total > args.amount:
        outputs.append({"recipient_pub": pub, "amount": total - args.amount})

    unsigned = [{"prev_tx_hash": u["tx_hash"], "output_index": int(u["output_index"])} for u in selected]
    fee = total - sum(o["amount"] for o in outputs)

    sk = SigningKey.from_string(bytes.fromhex(wallet["private_key"]), curve=SECP256k1)
    digest = hashlib.sha256(intent_message(network_id, pub, unsigned, outputs, fee).encode()).digest()
    signature = sk.sign_digest(digest).hex()

    inputs = [dict(i, signature=signature) for i in unsigned]
    created_at = int(time.time())

    payload = {
        "tx_hash": tx_hash_of(pub, inputs, outputs, signature, created_at),
        "sender_pub": pub,
        "tx_version": TX_VERSION,
        "network_id": network_id,
        "inputs": inputs,
        "outputs": outputs,
        "signature": signature,
        "created_at": created_at,
    }

    r = requests.post(f"{node}/transaction/receive", json=payload, timeout=30)
    if r.status_code != 200:
        sys.exit(f"Transaction refusée : {r.status_code} {r.text}")
    print(f"Transaction envoyée : {payload['tx_hash']}")
    print("Elle sera confirmée dès qu'un mineur trouvera le prochain bloc.")


def main():
    parser = argparse.ArgumentParser(description="Portefeuille CMIA")
    parser.add_argument("--node", default=DEFAULT_NODE)
    parser.add_argument("--wallet", default="wallet.json")
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("address")
    sub.add_parser("balance")
    send = sub.add_parser("send")
    send.add_argument("--to", required=True)
    send.add_argument("--amount", type=int, required=True)
    args = parser.parse_args()
    args.node = args.node.rstrip("/")

    wallet = load_wallet(args.wallet)
    if args.cmd == "address":
        print(wallet["public_key"])
    elif args.cmd == "balance":
        cmd_balance(args, wallet)
    elif args.cmd == "send":
        cmd_send(args, wallet)


if __name__ == "__main__":
    main()
